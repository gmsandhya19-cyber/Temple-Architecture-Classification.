# Temple Atlas frontend

Responsive React application for exploring and analyzing Indian temple architecture.

## Install and run on Windows

From the repository root:

```powershell
cd frontend
npm ci
Copy-Item .env.example .env
npm run dev
```

The checked-in `package-lock.json` makes `npm ci` reproducible. `.npmrc` keeps npm's cache inside `frontend/.npm-cache` to avoid Windows user-cache permission problems. With npm 11, if the esbuild postinstall script is blocked, run `npm approve-scripts esbuild` and then `npm run build`.

On this Windows setup, `npm run dev` builds the app and serves the production bundle at `http://localhost:5173` to avoid a Vite/esbuild dependency-scan permission failure. This local serving mode does not use hot reload; restart `npm run dev` after changing source files. If port 5173 is occupied, stop the existing Vite process before starting it again.

The default `VITE_API_URL=/api` uses the Vite development/preview proxy to reach `http://127.0.0.1:8000`. For a separately hosted backend, set `VITE_API_URL` in `.env` and rebuild. A production static host must proxy `/api` to the backend or use an explicit backend URL. Start the backend separately; see [backend setup](../backend/README.md). The backend allows Vite's local origins by default. Set its `CORS_ORIGINS` environment variable to the deployed frontend origin in production.

## Production build

```powershell
npm run build
npm run preview
```

Build output is written to `dist/`. The dashboard chart is lazy-loaded; Recharts is a separate vendor chunk and may trigger Vite's large-chunk advisory.

## Included pages and behavior

- Login and registration use the backend's auth routes. The access token is stored in `sessionStorage`.
- Dashboard shows account analyses, categories, recent predictions, and saved comparisons. Signed-out visitors see clearly marked sample data.
- Upload and prediction, image comparison, history, temple field guide, report generation/download, and profile/settings views are included.
- Profile settings support email changes and password changes; a password change invalidates all sessions and requires a new sign-in.
- Temple information is searchable by temple name, location, and architecture style through the API-backed reference directory.
- Uploads and comparisons require sign-in. User history and comparison data come from SQLite through the API; uploaded image previews use the authenticated image route.

The local classifier predicts broad style only and currently has about 43.3% cross-validation accuracy on 150 images. Optional AI part mapping can draw image-grounded boxes for visible style-specific parts when `ENABLE_AI_PART_DETECTION=true` and `GEMINI_API_KEY` are configured in `backend/.env`. When enabled, uploads are sent to Google Gemini for visual processing. Returned boxes are AI estimates and should be reviewed; no boxes are shown when the service is disabled, unavailable, or cannot identify visible parts. Comparison measurements still cover image-level shape/edges and color, not semantic differences such as a missing pillar.
