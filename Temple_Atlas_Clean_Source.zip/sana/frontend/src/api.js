const API_URL = (import.meta.env.VITE_API_URL || '/api').replace(/\/+$/, '')

export function token() { return sessionStorage.getItem('atlas_token') }

function responseError(body, status) {
  if (typeof body?.detail === 'string') return body.detail
  if (Array.isArray(body?.detail)) {
    return body.detail.map(item => item.msg || 'Invalid input').join('; ')
  }
  if (status >= 500) return 'The server could not process the request. Check that the backend is running and try again.'
  return 'The request could not be completed.'
}

async function apiFetch(path, options = {}) {
  const currentToken = token()
  const isSignIn = path === '/auth/login' || path === '/auth/register'
  const headers = new Headers(options.headers || {})
  if (currentToken && !isSignIn) headers.set('Authorization', `Bearer ${currentToken}`)
  const response = await fetch(`${API_URL}${path}`, { ...options, headers })
  if (response.status === 401 && !isSignIn && currentToken && token() === currentToken) {
    sessionStorage.removeItem('atlas_token')
    sessionStorage.removeItem('atlas_user')
    window.dispatchEvent(new Event('atlas-session-expired'))
    const error = new Error('Your session expired. Please sign in again.')
    error.status = 401
    throw error
  }
  return response
}

export async function authenticatedImageUrl(path) {
  const response = await apiFetch(path)
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error(body.detail || 'Could not load image.')
  }
  return URL.createObjectURL(await response.blob())
}

export async function request(path, options = {}) {
  const headers = new Headers(options.headers || {})
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json')
  let response
  try {
    response = await apiFetch(path, { ...options, headers })
  } catch (error) {
    if (error.status === 401) throw error
    throw new Error('Cannot reach the API. Start the backend and check VITE_API_URL.')
  }
  const type = response.headers.get('content-type') || ''
  const body = type.includes('application/json') ? await response.json() : await response.blob()
  if (!response.ok) {
    const error = new Error(responseError(body, response.status))
    error.status = response.status
    throw error
  }
  return body
}

export async function downloadBlob(path, filename) {
  const response = await apiFetch(path)
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error(body.detail || 'Could not download file.')
  }
  const url = URL.createObjectURL(await response.blob())
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.click()
  URL.revokeObjectURL(url)
}
