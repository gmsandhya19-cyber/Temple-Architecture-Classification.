import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import {
  Activity, ArrowDownToLine, ArrowLeftRight, ArrowRight, Bell, BookOpen, Check,
  ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Clock3, Compass, FileText,
  Grid2X2, ImagePlus, Landmark, LogOut, Menu, Plus, Search, Settings2, ShieldCheck,
  Sparkles, Upload, UserRound, X,
} from 'lucide-react'
import { authenticatedImageUrl, downloadBlob, request, token } from './api'

const ArchitectureChart = lazy(() => import('./Chart.jsx'))

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Grid2X2 },
  { id: 'upload', label: 'Upload image', icon: ImagePlus },
  { id: 'compare', label: 'Image comparison', icon: ArrowLeftRight },
  { id: 'history', label: 'Prediction history', icon: Clock3 },
]
const categoryInfo = {
  NAGARA: { title: 'Nagara', region: 'Northern India', color: 'saffron', symbol: '⌂' },
  DRAVIDA: { title: 'Dravida', region: 'Southern India', color: 'green', symbol: '◈' },
  VESARA: { title: 'Vesara', region: 'Deccan region', color: 'blue', symbol: '✳' },
  UNKNOWN: { title: 'Unclassified', region: 'Awaiting model', color: 'gray', symbol: '?' },
}
const architectureParts = {
  NAGARA: [
    ['Kalasa', 'Finial at the summit'], ['Amalaka', 'Ribbed crown disk'], ['Griva', 'Neck below the crown'],
    ['Shikhara', 'Curving tower above the sanctum'], ['Urushringa', 'Smaller attached spires'], ['Jangha', 'Main wall section'],
    ['Mandapa', 'Pillared assembly hall'], ['Antarala', 'Vestibule before the sanctum'], ['Garbhagriha', 'Sanctum'],
    ['Jagati', 'Raised platform'], ['Adhisthana', 'Moulded base'],
  ],
  DRAVIDA: [
    ['Stupi / Kalasa', 'Finial at the summit'], ['Griva', 'Neck above the tower tiers'], ['Shikhara / Vimana', 'Pyramidal sanctuary superstructure'],
    ['Tala', 'Horizontal storey or tier'], ['Kapota', 'Projecting cornice'], ['Kudu', 'Arch-shaped dormer motif'],
    ['Mandapa', 'Pillared assembly hall'], ['Antarala', 'Vestibule before the sanctum'], ['Garbhagriha', 'Sanctum'],
    ['Jagati', 'Raised platform'], ['Adhisthana', 'Moulded base'],
  ],
  VESARA: [
    ['Stupi / Kalasa', 'Finial at the summit'], ['Griva', 'Neck below the crown'], ['Shikhara / Vimana', 'Tower form with regional hybrid features'],
    ['Tala', 'Horizontal storey or tier'], ['Jangha', 'Main wall section'], ['Kapota', 'Projecting cornice'],
    ['Mandapa', 'Pillared assembly hall'], ['Antarala', 'Vestibule before the sanctum'], ['Garbhagriha', 'Sanctum'],
    ['Jagati', 'Raised platform'], ['Adhisthana', 'Moulded base'],
  ],
}
const demoRows = [
  { id: 'demo-1', filename: 'Brihadisvara Temple.jpg', architecture: 'DRAVIDA', confidence: null, created_at: new Date(Date.now() - 3600000).toISOString(), analysis: 'The tall, pyramidal vimana and richly sculpted tiers are characteristic of Dravidian temple design.' },
  { id: 'demo-2', filename: 'Modhera Sun Temple.jpg', architecture: 'NAGARA', confidence: null, created_at: new Date(Date.now() - 86400000).toISOString(), analysis: 'The curvilinear shikhara and north Indian plan align with Nagara architectural traditions.' },
  { id: 'demo-3', filename: 'Hoysaleswara Temple.jpg', architecture: 'VESARA', confidence: null, created_at: new Date(Date.now() - 172800000).toISOString(), analysis: 'The ornate Deccan stonework reflects a synthesis associated with Vesara architecture.' },
]
const demoComparisons = [
  { id: 'cmp-demo-1', similarity: 0.78, created_at: new Date(Date.now() - 5 * 3600000).toISOString() },
  { id: 'cmp-demo-2', similarity: 0.61, created_at: new Date(Date.now() - 30 * 3600000).toISOString() },
]

function dateLabel(value) {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return 'Recently'
  return new Intl.DateTimeFormat('en', { day: 'numeric', month: 'short', year: 'numeric' }).format(date)
}
function shortTime(value) {
  const elapsed = Date.now() - new Date(value).getTime()
  if (!Number.isFinite(elapsed) || elapsed < 0) return 'Just now'
  if (elapsed < 3600000) return `${Math.max(1, Math.floor(elapsed / 60000))}m ago`
  if (elapsed < 86400000) return `${Math.floor(elapsed / 3600000)}h ago`
  if (elapsed < 604800000) return `${Math.floor(elapsed / 86400000)}d ago`
  return dateLabel(value)
}
function classLabel(value) { return categoryInfo[value]?.title || value || 'Unclassified' }

export default function App() {
  const [accessToken, setAccessToken] = useState(token())
  const [user, setUser] = useState(() => { try { return JSON.parse(sessionStorage.getItem('atlas_user') || 'null') } catch { return null } })
  const [page, setPage] = useState('dashboard')
  const [history, setHistory] = useState(() => accessToken ? [] : demoRows)
  const [comparisons, setComparisons] = useState(() => accessToken ? [] : demoComparisons)
  const [selected, setSelected] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [showDemo, setShowDemo] = useState(!accessToken)

  async function loadData() {
    try {
      const [rows, comps] = await Promise.all([request('/history?limit=100'), request('/comparisons?limit=100')])
      setHistory(rows.items || [])
      setComparisons(comps.items || [])
      setShowDemo(false)
    } catch (err) {
      if (err.status !== 401) setError(err.message)
    }
  }
  useEffect(() => {
    function sessionExpired() {
      setAccessToken(null); setUser(null); setSelected(null)
      setHistory(demoRows); setComparisons(demoComparisons); setShowDemo(true)
      setBusy(false); setMenuOpen(false); setPage('login')
      setError('Your session expired. Please sign in again.')
    }
    window.addEventListener('atlas-session-expired', sessionExpired)
    return () => window.removeEventListener('atlas-session-expired', sessionExpired)
  }, [])
  useEffect(() => { if (accessToken) loadData() }, [accessToken])

  function flash(message) { setNotice(message); window.setTimeout(() => setNotice(''), 3000) }
  function go(next) { setPage(next); setMenuOpen(false); setError('') }
  function acceptSession(data) {
    sessionStorage.setItem('atlas_token', data.access_token)
    sessionStorage.setItem('atlas_user', JSON.stringify(data.user))
    setAccessToken(data.access_token); setUser(data.user); setPage('dashboard'); setShowDemo(false); setError('')
  }
  async function signOut(message = 'You are signed out.') {
    try { if (accessToken) await request('/auth/logout', { method: 'POST' }) } catch { /* clear local session even when offline */ }
    sessionStorage.removeItem('atlas_token'); sessionStorage.removeItem('atlas_user')
    setAccessToken(null); setUser(null); setSelected(null); setPage('dashboard'); setHistory(demoRows); setComparisons(demoComparisons); setShowDemo(true)
    flash(message)
  }
  async function openResult(row) {
    setSelected(row); go('result')
    if (accessToken && row?.id && !String(row.id).startsWith('demo')) {
      try {
        const detail = await request(`/history/${row.id}`)
        if (detail.image_url) detail.preview_url = await authenticatedImageUrl(detail.image_url)
        setSelected(detail)
      } catch (err) { setError(err.message) }
    }
  }

  if (!accessToken && ['login', 'register'].includes(page)) {
    return <AuthPage mode={page} onMode={setPage} onSuccess={acceptSession} error={error} setError={setError} />
  }

  const greeting = user?.email?.split('@')[0] || 'there'
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
      <a className="brand" href="#dashboard" onClick={e => { e.preventDefault(); go('dashboard') }}>
        <span className="brand-mark"><Landmark size={21} strokeWidth={1.7} /></span>
        <span className="brand-copy"><strong>temple<span>atlas</span></strong><small>ARCHITECTURE STUDIO</small></span>
      </a>
      <div className="workspace-label">WORKSPACE <ChevronDown size={13} /></div>
      <nav className="side-nav" aria-label="Main navigation">
        {navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${page === id || (id === 'history' && ['result', 'temple', 'report'].includes(page)) ? 'active' : ''}`} onClick={() => go(id)}><Icon size={18} /><span>{label}</span>{id === 'history' && history.length > 0 && <i className="nav-count">{history.length}</i>}</button>)}
      </nav>
      <div className="nav-divider" />
      <div className="workspace-label">YOUR LIBRARY</div>
      <nav className="side-nav">
        <button className={`nav-item ${page === 'temples' ? 'active' : ''}`} onClick={() => go('temples')}><BookOpen size={18} /><span>Temple information</span></button>
        <button className={`nav-item ${page === 'reports' ? 'active' : ''}`} onClick={() => go('reports')}><FileText size={18} /><span>Reports</span></button>
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><CircleHelp size={17} /></div><strong>New to temple styles?</strong><span>Explore our field guide to the three great traditions.</span><button onClick={() => go('temples')}>Read the field guide <ArrowRight size={13} /></button></div>
        <button className={`nav-item ${page === 'profile' ? 'active' : ''}`} onClick={() => go('profile')}><Settings2 size={18} /><span>Settings</span></button>
        <div className="user-chip"><div className="avatar">{(user?.email?.[0] || 'A').toUpperCase()}</div><div className="user-meta"><b>{user?.email || 'Guest explorer'}</b><span>{user ? 'Personal workspace' : 'Demo workspace'}</span></div><button aria-label="Sign out" title="Sign out" onClick={() => signOut()}><LogOut size={16} /></button></div>
      </div>
    </aside>

    {menuOpen && <button className="scrim" aria-label="Close navigation" onClick={() => setMenuOpen(false)} />}
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu icon-button" onClick={() => setMenuOpen(true)} aria-label="Open menu"><Menu size={19} /></button>
        <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><b>{pageTitle(page)}</b></div>
        <div className="top-actions"><div className="search-box"><Search size={16} /><input placeholder="Search your analyses..." value={search} onChange={e => setSearch(e.target.value)} /><kbd>⌘ K</kbd></div><button className="icon-button notification" aria-label="Notifications" onClick={() => flash('You’re all caught up.')}><Bell size={18} /><i /></button><button className="top-avatar" onClick={() => go('profile')}>{(user?.email?.[0] || 'A').toUpperCase()}</button></div>
      </header>
      {error && <div className="alert"><span>{error}</span><button aria-label="Dismiss" onClick={() => setError('')}><X size={16} /></button></div>}
      {showDemo && <div className="demo-banner"><Sparkles size={15} /><span>You’re viewing a preview with sample analyses. Create an account to save your own research.</span><button onClick={() => { setPage('register'); setError('') }}>Create account <ArrowRight size={14} /></button></div>}
      <div className="content-wrap">
        {page === 'dashboard' && <Dashboard userName={greeting} history={filtered(history, search)} comparisons={comparisons} onUpload={() => go('upload')} onResult={openResult} onCompare={() => go('compare')} onHistory={() => go('history')} onTemple={() => go('temples')} />}
        {page === 'upload' && (accessToken ? <UploadPage busy={busy} setBusy={setBusy} setError={setError} onResult={row => { setHistory(old => [row, ...old]); openResult(row); flash('Analysis is complete.') }} /> : <SignInGate onSignIn={() => go('login')} />)}
        {page === 'result' && <ResultPage key={selected?.id} onMapped={updated => { setSelected(old => old?.id === updated.id ? ({ ...old, ...updated }) : old); loadData() }} row={selected || history[0]} onCompare={() => go('compare')} onReport={() => go('report')} onHistory={() => go('history')} flash={flash} />}
        {page === 'compare' && (accessToken ? <ComparePage key={selected?.id || 'new'} initialReference={selected} busy={busy} setBusy={setBusy} setError={setError} onCompared={row => { setComparisons(old => [row, ...old]); flash('Images compared successfully.'); loadData() }} comparisons={comparisons} /> : <SignInGate onSignIn={() => go('login')} />)}
        {page === 'history' && (accessToken ? <HistoryPage rows={filtered(history, search)} onResult={openResult} onUpload={() => go('upload')} /> : <SignInGate onSignIn={() => go('login')} />)}
        {page === 'temples' && <TemplesPage onUpload={() => go('upload')} />}
        {page === 'reports' && (accessToken ? <ReportsPage rows={history} onReport={row => { setSelected(row); go('report') }} onUpload={() => go('upload')} /> : <SignInGate onSignIn={() => go('login')} />)}
        {page === 'report' && (accessToken ? <ReportPage row={selected || history[0]} setError={setError} flash={flash} /> : <SignInGate onSignIn={() => go('login')} />)}
        {page === 'profile' && (accessToken ? <ProfilePage user={user} onLogout={signOut} onUserUpdated={next => { setUser(next); sessionStorage.setItem('atlas_user', JSON.stringify(next)) }} flash={flash} /> : <SignInGate onSignIn={() => go('login')} />)}
      </div>
      <footer className="footer"><span>© 2025 Temple Atlas</span><span>Made for curious minds <span className="footer-heart">✳</span></span><button onClick={() => go('temples')}>About the styles</button></footer>
    </main>
    {notice && <div className="toast"><Check size={16} />{notice}</div>}
  </div>
}

function pageTitle(page) {
  return ({ dashboard: 'Dashboard', upload: 'Upload image', result: 'Analysis result', compare: 'Image comparison', history: 'Prediction history', temples: 'Temple information', reports: 'Reports', report: 'Analysis report', profile: 'Profile & settings' })[page] || 'Dashboard'
}
function filtered(rows, query) { return query ? rows.filter(row => `${row.filename} ${row.architecture}`.toLowerCase().includes(query.toLowerCase())) : rows }

function AuthPage({ mode, onMode, onSuccess, error, setError }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  async function submit(event) {
    event.preventDefault(); setLoading(true); setError('')
    try {
      const data = await request(`/auth/${mode}`, { method: 'POST', body: JSON.stringify({ email, password }) })
      onSuccess(data)
    } catch (err) { setError(err.message) } finally { setLoading(false) }
  }
  return <div className="auth-layout"><div className="auth-visual"><div className="auth-visual-overlay" /><a className="brand auth-brand" href="#"><span className="brand-mark"><Landmark size={21} /></span><span className="brand-copy"><strong>temple<span>atlas</span></strong><small>ARCHITECTURE STUDIO</small></span></a><div className="auth-quote"><span className="eyebrow light">A LIVING ARCHIVE OF THE SUBCONTINENT</span><h1>Stone holds<br />stories.</h1><p>Discover the forms, details, and histories behind India's extraordinary temple architecture.</p><div className="auth-source"><span /> 01 — 03 &nbsp; · &nbsp; BRIHADISVARA, THANJAVUR</div></div><div className="auth-visual-foot"><span>EXPLORE. UNDERSTAND. PRESERVE.</span><span>EST. MMXXIV</span></div></div>
    <div className="auth-panel"><div className="auth-top"><span>{mode === 'login' ? 'New to Temple Atlas?' : 'Already have an account?'}</span><button onClick={() => onMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Create account' : 'Sign in'} <ArrowRight size={15} /></button></div><div className="auth-form-wrap"><Landmark className="auth-form-emblem" aria-hidden="true" /><span className="eyebrow">YOUR PERSONAL RESEARCH SPACE</span><h2>{mode === 'login' ? 'Welcome back' : 'Start exploring'}</h2><p className="muted">{mode === 'login' ? 'Sign in to continue your exploration of Indian architecture.' : 'Create an account to save and revisit your discoveries.'}</p>
      {error && <div className="auth-error">{error}</div>}
      <form onSubmit={submit} className="auth-form"><label>Email address<input type="email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" placeholder="you@example.com" /></label><label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} placeholder="At least 8 characters" /></label>{mode === 'login' && <button type="button" className="forgot-link" onClick={() => setError('Password reset is not configured. Please contact your administrator.')}>Forgot password?</button>}<button className="primary-button auth-submit" disabled={loading}>{loading ? 'Please wait...' : mode === 'login' ? 'Sign in to Temple Atlas' : 'Create your account'} <ArrowRight size={16} /></button></form>
      <div className="auth-or"><span /> SECURE ACCESS <span /></div><div className="auth-safe"><ShieldCheck size={16} /><span>Your research and images are private to your account.</span></div>
    </div><div className="auth-foot"><span>© 2025 Temple Atlas</span><span>Privacy &nbsp; · &nbsp; Terms</span></div></div></div>
}

function Dashboard({ userName, history, comparisons, onUpload, onResult, onCompare, onHistory, onTemple }) {
  const counts = useMemo(() => history.reduce((acc, row) => { const name = row.architecture || 'UNKNOWN'; acc[name] = (acc[name] || 0) + 1; return acc }, {}), [history])
  const chartData = ['NAGARA', 'DRAVIDA', 'VESARA'].map(key => ({ name: classLabel(key), count: counts[key] || 0, fill: categoryInfo[key].color }))
  const total = history.length
  const confidenceRows = history.filter(row => row.confidence != null && Number.isFinite(Number(row.confidence)))
  const avg = confidenceRows.length ? confidenceRows.reduce((sum, row) => sum + Number(row.confidence), 0) / confidenceRows.length : null
  return <div className="page dashboard-page">
    <div className="welcome-row"><div><span className="eyebrow">{new Intl.DateTimeFormat('en', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()).toUpperCase()} <span className="sun-dot">✳</span></span><h1>Good morning, {userName}<span className="greeting-mark">.</span></h1><p>Here's what's happening in your architecture journal.</p></div><button className="primary-button" onClick={onUpload}><Plus size={17} /> New analysis</button></div>
    <section className="metrics-grid"><MetricCard label="Total analyses" value={total} detail="Across your research" icon={Activity} color="peach" /><MetricCard label="Most explored style" value={topCategory(counts)} detail="Based on your analyses" icon={Compass} color="sage" /><MetricCard label="Average confidence" value={avg == null ? 'N/A' : `${(avg * 100).toFixed(1)}%`} detail="Model score, not accuracy" icon={Sparkles} color="lavender" /><MetricCard label="Image comparisons" value={comparisons.length} detail="Visual studies saved" icon={ArrowLeftRight} color="sand" /></section>
    <section className="dashboard-grid"><div className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR RESEARCH</span><h2>Architecture categories</h2></div><button className="text-button" onClick={onHistory}>View history <ArrowRight size={14} /></button></div><div className="chart-meta"><strong>{total}</strong><span>analyses in your journal</span><span className="chart-legend"><i className="legend-dot saffron" />Nagara <i className="legend-dot green" />Dravida <i className="legend-dot blue" />Vesara</span></div><div className="chart-wrap"><Suspense fallback={<div className="chart-loading">Loading chart…</div>}><ArchitectureChart data={chartData} /></Suspense></div><div className="category-legend-cards">{['NAGARA', 'DRAVIDA', 'VESARA'].map(key => <button className="category-mini" key={key} onClick={onTemple}><span className={`category-symbol ${categoryInfo[key].color}`}>{categoryInfo[key].symbol}</span><span><b>{classLabel(key)}</b><small>{counts[key] || 0} studies</small></span><ChevronRight size={14} /></button>)}</div></div>
      <div className="panel recent-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR JOURNAL</span><h2>Recent predictions</h2></div><button className="icon-button subtle" onClick={onHistory} aria-label="View history"><ArrowRight size={17} /></button></div><div className="recent-list">{history.slice(0, 4).map(row => <PredictionRow key={row.id} row={row} onClick={() => onResult(row)} />)}{history.length === 0 && <EmptyState title="Your journal is ready" text="Upload a temple image to make your first analysis." action="Start an analysis" onClick={onUpload} />}</div><button className="panel-bottom-link" onClick={onHistory}>View all analyses <ArrowRight size={14} /></button></div></section>
    <section className="bottom-grid"><div className="panel comparison-panel"><div className="panel-heading"><div><span className="eyebrow">SIDE BY SIDE</span><h2>Recent comparisons</h2></div><button className="text-button" onClick={onCompare}>New comparison <Plus size={14} /></button></div><div className="comparison-list">{comparisons.slice(0, 3).map((row, i) => <div className="comparison-item" key={row.id}><div className="comparison-thumb"><Landmark size={18} /><ArrowLeftRight size={12} /><Landmark size={18} /></div><div className="comparison-desc"><b>{row.reference_name || ['Brihadisvara ↔ Airavatesvara', 'Modhera ↔ Konark Sun Temple', 'Hoysaleswara ↔ Chennakesava'][i % 3]}</b><span>{shortTime(row.created_at)}</span></div><span className="similarity-pill">{Math.round(row.similarity * 100)}% match</span></div>)}{comparisons.length === 0 && <EmptyState title="No comparisons yet" text="Compare two images side by side." action="Compare images" onClick={onCompare} />}</div></div><div className="field-note"><div className="field-note-top"><span className="eyebrow light">FIELD NOTE &nbsp; / &nbsp; 01</span><span className="note-spark">✳</span></div><h2>A tower tells<br />you where you are.</h2><p>A curving shikhara reaching skyward? You're likely looking at a Nagara temple. A stepped pyramid of tiers? That's a Dravida hallmark.</p><button onClick={onTemple}>Explore the field guide <ArrowRight size={14} /></button><span className="note-lines" /></div></section>
  </div>
}

function topCategory(counts) { const entry = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]; return entry ? classLabel(entry[0]) : '—' }
function chartColor(name) { return ({ saffron: '#d88c52', green: '#729176', blue: '#8295a3' })[name] }
function MetricCard({ label, value, detail, icon: Icon, color }) { return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className={`metric-icon ${color}`}><Icon size={17} /></span></div><strong>{value}</strong><small>{detail}</small><span className="metric-rule" /></div> }
function PredictionRow({ row, onClick }) { const style = categoryInfo[row.architecture] || categoryInfo.UNKNOWN; return <button className="prediction-row" onClick={onClick}><span className={`row-thumb ${style.color}`}><Landmark size={19} /></span><span className="row-copy"><b>{row.filename || 'Temple image'}</b><span><i className={`status-dot ${style.color}`} />{classLabel(row.architecture)} <span className="row-confidence">· {row.confidence == null ? 'sample' : `${(row.confidence * 100).toFixed(1)}% confidence`}</span></span></span><span className="row-date">{shortTime(row.created_at)}</span><ChevronRight size={15} className="row-chevron" /></button> }
function EmptyState({ title, text, action, onClick }) { return <div className="empty-state"><span className="empty-icon"><ImagePlus size={18} /></span><b>{title}</b><span>{text}</span>{action && <button onClick={onClick}>{action} <ArrowRight size={13} /></button>}</div> }

function SignInGate({ onSignIn }) { return <div className="page subpage"><PageIntro eyebrow="YOUR PRIVATE WORKSPACE" title="Sign in to start a study." text="Create an account or sign in to upload images, save predictions, and compare temple photographs." /><div className="panel sign-in-gate"><span className="gate-icon"><ShieldCheck size={23} /></span><div><b>Your research stays with you.</b><p>Analysis and comparison tools are available in your personal workspace.</p></div><button className="primary-button" onClick={onSignIn}>Sign in or register <ArrowRight size={15} /></button></div></div> }

function UploadPage({ busy, setBusy, setError, onResult }) {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState('')
  const inputRef = useRef(null)
  function selectFile(next) {
    if (!next) return
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(next.type)) { setError('Choose a JPEG, PNG, or WebP image.'); return }
    if (next.size > 10 * 1024 * 1024) { setError('Image must be smaller than 10 MB.'); return }
    setError(''); setFile(next); setPreview(URL.createObjectURL(next))
  }
  async function analyze() {
    if (!file) { setError('Choose an image before starting analysis.'); return }
    setBusy(true); setError('')
    try {
      const form = new FormData(); form.append('image', file)
      const result = await request('/analysis/predict', { method: 'POST', body: form })
      result.preview_url = preview
      onResult(result)
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }
  return <div className="page subpage"><PageIntro eyebrow="UPLOAD IMAGE" title="A new architectural discovery" text="Upload a temple image to explore its architectural style and study its distinctive forms." />
    <div className="upload-layout"><div className={`dropzone ${file ? 'has-file' : ''}`} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); selectFile(e.dataTransfer.files[0]) }} onClick={() => inputRef.current?.click()} role="button" tabIndex={0} onKeyDown={e => e.key === 'Enter' && inputRef.current?.click()}>
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => selectFile(e.target.files[0])} />
      {preview ? <><img className="upload-preview" src={preview} alt="Selected temple preview" /><button className="remove-file" onClick={e => { e.stopPropagation(); setFile(null); setPreview('') }} aria-label="Remove image"><X size={15} /></button><div className="upload-file-meta"><b>{file.name}</b><span>{(file.size / 1024 / 1024).toFixed(2)} MB · Ready for analysis</span></div></> : <div className="drop-content"><span className="upload-cloud"><Upload size={22} /></span><b>Drop your image here</b><span>or <em>browse files</em> on your device</span><small>JPEG, PNG or WebP · Max 10 MB</small></div>}
    </div><div className="upload-sidebar"><div className="panel upload-guide"><span className="eyebrow">A GOOD IMAGE GOES A LONG WAY</span><h3>For the clearest reading</h3><ul><li><Check size={15} /> Use a sharp, well-lit image</li><li><Check size={15} /> Include the tower or main structure</li><li><Check size={15} /> Keep the temple centered in frame</li><li><Check size={15} /> Avoid heavy filters or overlays</li></ul><div className="upload-format"><ShieldCheck size={15} /><span>Images are stored in your account. When optional AI part mapping is enabled, uploads are also sent to Gemini for visual analysis.</span></div></div><div className="upload-note"><Sparkles size={16} /><span>The classifier predicts architecture style; optional image AI maps visible architectural parts.</span></div></div></div>
    <div className="upload-actions"><button className="secondary-button" onClick={() => { setFile(null); setPreview('') }}>Clear selection</button><button className="primary-button" onClick={analyze} disabled={!file || busy}>{busy ? <><span className="spinner" /> Analyzing image...</> : <>Start analysis <ArrowRight size={16} /></>}</button></div>
  </div>
}

function PageIntro({ eyebrow, title, text, action }) { return <div className="page-intro"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{text}</p></div>{action}</div> }

function ResultPage({ row, onCompare, onReport, onHistory, flash, onMapped }) {
  const [mapping, setMapping] = useState(false)
  const [mappingError, setMappingError] = useState('')
  const autoMappingStarted = useRef(false)
  const mappingInFlight = useRef(false)
  async function retryMapping() {
    if (mappingInFlight.current) return
    mappingInFlight.current = true
    setMapping(true); setMappingError('')
    try {
      const updated = await request(`/history/${row.id}/parts`, { method: 'POST' })
      onMapped(updated)
      flash(updated.parts?.length ? 'AI part mapping updated.' : 'No clearly identifiable parts found.')
    } catch (error) { setMappingError(error.message) }
    finally { mappingInFlight.current = false; setMapping(false) }
  }
  useEffect(() => {
    if (row?.feature_detection_status === 'pending' && !autoMappingStarted.current && token()) {
      autoMappingStarted.current = true
      retryMapping()
    }
  }, [row?.id, row?.feature_detection_status])
  if (!row) return <div className="page subpage"><PageIntro eyebrow="ANALYSIS" title="No result selected" text="Run an image analysis to see your results here." /><button className="primary-button" onClick={onHistory}>View history <ArrowRight size={15} /></button></div>
  const style = categoryInfo[row.architecture] || categoryInfo.UNKNOWN
  const rawConfidence = Number(row.confidence)
  const confidence = Number.isFinite(rawConfidence) ? Math.min(1, Math.max(0, rawConfidence)) : 0
  const displayScore = confidence * 100
  const parts = Array.isArray(row.parts) ? row.parts : []
  const partsStatus = mapping ? 'mapping' : mappingError ? 'unavailable' : row.feature_detection_status || 'not_configured'
  const featureList = row.features ? Object.entries(row.features).map(([key, value]) => `${key.replaceAll('_', ' ')}: ${value}`) : []
  return <div className="page subpage"><div className="result-back"><button onClick={onHistory}><ChevronLeft size={16} /> Back to journal</button><span>ANALYSIS ID &nbsp;·&nbsp; {String(row.id || '').slice(0, 8).toUpperCase()}</span></div><div className="result-layout"><div className="result-image-card"><div className="result-image-wrap">{row.preview_url ? <><img src={row.preview_url} alt="Temple image with AI-detected architectural part boxes" />{parts.length && row.image_dimensions ? <VisionPartOverlay parts={parts} dimensions={row.image_dimensions} /> : <PartMappingStatus status={partsStatus} note={row.parts_note} />}</> : <TempleIllustration variant={row.architecture} />}</div><div className="result-image-caption"><span><ImagePlus size={14} /> {row.filename || 'Temple image'}</span><span>{dateLabel(row.created_at || new Date())}</span></div></div><div className="result-detail"><span className="eyebrow">YOUR ARCHITECTURAL READING</span><div className="result-style-row"><span className={`result-style-symbol ${style.color}`}>{style.symbol}</span><div><h1>{classLabel(row.architecture)}</h1><span>{style.region} tradition</span></div><span className="result-badge"><Check size={13} /> ANALYZED</span></div>
      <div className="confidence-panel"><div className="confidence-head"><span>Model confidence</span><strong>{displayScore.toFixed(1)}<small>%</small></strong></div><div className="confidence-track"><span style={{ width: `${displayScore}%` }} /></div><div className="confidence-foot"><span></span><span>Model confidence: {(confidence * 100).toFixed(1)}%</span></div></div>
      {token() && row.id && !String(row.id).startsWith('demo') && <div><button className="secondary-button" disabled={mapping} onClick={retryMapping}>{mapping ? 'Mapping parts - please wait...' : 'Retry AI mapping'}</button>{mappingError && <p role="alert">{mappingError}</p>}</div>}
      <div className="result-section"><div className="section-title"><h3>Architectural parts</h3><span>{parts.length ? `${parts.length} AI BOXES` : partsStatus.replaceAll('_', ' ').toUpperCase()}</span></div>{parts.length ? <div className="feature-list">{parts.map(part => <div className="feature-item" key={`${part.name}-${part.bbox.join('-')}`}><span className="feature-check"><Check size={13} /></span><span><b>{part.name}</b>{part.evidence ? ` · ${part.evidence}` : ''}</span></div>)}</div> : <p className="features-empty">{['pending', 'mapping'].includes(partsStatus) ? 'Your prediction is ready. AI part boxes are loading separately; you can continue using the app.' : partsStatus === 'not_configured' ? 'Enable AI part detection in the backend to map visible parts onto this photo.' : partsStatus === 'unavailable' ? 'The vision service was temporarily unavailable. Retry mapping for this saved photo.' : 'The AI did not find any clearly visible parts it could label in this photo.'}</p>}</div>
      {architectureParts[row.architecture] && <ArchitecturePartsGuide architecture={row.architecture} hasAiMapping={parts.length > 0} />}
      <div className="result-section explanation"><div className="section-title"><h3>Reading the form</h3><BookOpen size={15} /></div><p>{row.analysis || 'No additional analysis was returned. The model prediction should be checked against architectural details and historical context.'}</p><span className="model-disclaimer"><ShieldCheck size={13} /> AI-assisted reading · verify with a specialist</span></div>
      <div className="result-actions"><button className="primary-button" onClick={onCompare}><ArrowLeftRight size={16} /> Compare image</button><button className="secondary-button" onClick={onReport}><FileText size={15} /> Download report</button></div>
    </div></div><div className="result-disclaimer"><Sparkles size={14} /> Predictions are generated from a small research dataset and may not capture every regional variation.</div></div>
}

function ArchitecturePartsGuide({ architecture, hasAiMapping }) {
  const parts = architectureParts[architecture]
  const left = parts.filter((_, index) => index % 2 === 0)
  const right = parts.filter((_, index) => index % 2 === 1)
  const callouts = (items, side) => items.map(([name], index) => {
    const globalIndex = parts.findIndex(([partName]) => partName === name)
    const y = 53 + index * 48
    const anchorY = 74 + globalIndex * 21
    const x1 = side === 'left' ? 143 : 457
    const x2 = side === 'left' ? 265 : 335
    return <g key={`${side}-${name}`}><path d={`M ${x1} ${y - 9} L ${side === 'left' ? 215 : 385} ${y - 9} L ${x2} ${anchorY}`} /><circle cx={x2} cy={anchorY} r="3" /><text x={side === 'left' ? 8 : 592} y={y - 5} textAnchor={side === 'left' ? 'start' : 'end'}>{name}</text></g>
  })
  return <section className="parts-guide result-section"><div className="section-title"><h3>Temple parts guide</h3><span>STYLE REFERENCE</span></div><p className="parts-guide-note">{hasAiMapping ? 'The boxes on the uploaded photo are AI vision estimates of parts visible in that image. Review them carefully. This diagram and glossary explain common terms for the style.' : `This diagram and glossary explain common ${classLabel(architecture)} terms. Enable AI part mapping to request image-specific boxes.`} Names and forms vary by temple and region.</p><div className="parts-diagram"><svg viewBox="0 0 600 350" role="img" aria-label={`${classLabel(architecture)} temple reference diagram with architectural part labels`}>
    <g className="parts-callouts">{callouts(left, 'left')}{callouts(right, 'right')}</g>
    <g className="parts-temple">
      <path className="parts-ground" d="M235 309h130v13H235zM222 322h156v9H222z" />
      <path className="parts-body" d="M250 307V225h100v82M243 225h114M250 240h100M257 257h86M262 274h76M269 291h62" />
      <path className="parts-roof" d={architecture === 'DRAVIDA' ? 'M260 225h80l-7-16h-66zm7-16h66l-7-16h-52zm7-16h52l-8-17h-36zm8-17h36l-9-19h-18z' : architecture === 'VESARA' ? 'M260 225h80l-9-19h-62l-6-16h50l-9-18h-32l-8-18h16l10-22 10 22h16l-9 18h-11v24h45l-9 29z' : 'M260 225h80l-6-28-8-25-11-22-15-24-15 24-11 22-8 25z'} />
      <path className="parts-cap" d="M279 126h42l-7-9h-28zM285 113h30l-6-8h-18z" />
      <path className="parts-finial" d="M300 70v32m-8 0h16l-8 9z" />
      <path className="parts-door" d="M286 307v-39a14 14 0 0 1 28 0v39" />
      <path className="parts-line" d="M300 110v16" />
    </g>
  </svg></div><div className="parts-glossary">{parts.map(([name, meaning]) => <div className="parts-term" key={name}><b>{name}</b><span>{meaning}</span></div>)}</div><p className="parts-ratha-note"><b>From your chariot reference:</b> Danda and Ketana (flag) label parts of a Jagannath Ratha assembly, so they are kept separate from temple-style terminology.</p></section>
}

function PartMappingStatus({ status, note }) {
  const messages = { pending: 'AI PART MAPPING QUEUED', mapping: 'AI PART MAPPING IN PROGRESS', unavailable: 'AI PART MAPPING UNAVAILABLE', no_visible_parts: 'NO CLEAR PARTS IDENTIFIED', unsupported_style: 'STYLE COULD NOT BE CLASSIFIED', not_available: 'PART MAPPING UNAVAILABLE' }
  const message = messages[status] || 'ENABLE AI PART MAPPING'
  return <><div className="image-overlay-note">{message}</div>{note && <div className="image-overlay-detail">{note}</div>}</>
}

function VisionPartOverlay({ parts, dimensions }) {
  const viewHeight = 1000 * dimensions.height / dimensions.width
  const fontSize = Math.max(20, Math.min(34, viewHeight * 0.032))
  const labelHeight = fontSize * 1.55
  return <><div className="image-overlay-note">AI VISION · BOXES ON VISIBLE PARTS</div><svg className="vision-part-overlay" viewBox={`0 0 1000 ${viewHeight}`} preserveAspectRatio="xMidYMid slice" aria-label="AI-detected temple parts">
    {parts.map((part, index) => {
      const [x1, y1, x2, y2] = part.bbox
      const boxY = y1 / 1000 * viewHeight
      const boxHeight = (y2 - y1) / 1000 * viewHeight
      const labelY = Math.max(0, boxY - labelHeight)
      const labelWidth = Math.min(440, part.name.length * fontSize * 0.63 + fontSize * 0.9)
      const labelX = x1 + labelWidth <= 1000 ? x1 : Math.max(0, x2 - labelWidth)
      return <g key={`${part.name}-${index}`} className="vision-part-box"><rect className="vision-bbox" x={x1} y={boxY} width={x2 - x1} height={boxHeight} rx={5} /><rect className="vision-label-bg" x={labelX} y={labelY} width={labelWidth} height={labelHeight} rx={4} /><text x={labelX + fontSize * 0.38} y={labelY + labelHeight * 0.7} fontSize={fontSize}>{part.name}</text></g>
    })}
  </svg></>
}

function TempleIllustration({ variant = 'NAGARA' }) { const color = variant === 'DRAVIDA' ? '#758f79' : variant === 'VESARA' ? '#8294a2' : '#be8662'; return <div className="temple-illustration" style={{ '--temple-color': color }}><div className="temple-sun" /><div className="temple-art"><div className="temple-spire"/><div className="temple-roof"/><div className="temple-upper"><i/><i/><i/></div><div className="temple-ledge"/><div className="temple-body"><i/><i/><i/><i/><i/></div><div className="temple-base"/><div className="temple-ground"/></div><span className="temple-art-label">STUDY IN STONE · {classLabel(variant).toUpperCase()}</span></div> }

function ComparePage({ initialReference, busy, setBusy, setError, onCompared, comparisons }) {
  const [files, setFiles] = useState(() => [initialReference?.filename && initialReference?.preview_url ? { name: initialReference.filename, preview_url: initialReference.preview_url } : null, null])
  const [previews, setPreviews] = useState(() => [initialReference?.preview_url || '', ''])
  const inputRefs = [useRef(null), useRef(null)]
  function choose(index, file) {
    if (!file) return
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 10 * 1024 * 1024) { setError('Choose a JPEG, PNG, or WebP image smaller than 10 MB.'); return }
    const nextFiles = [...files]; nextFiles[index] = file; setFiles(nextFiles)
    const nextPreviews = [...previews]; nextPreviews[index] = URL.createObjectURL(file); setPreviews(nextPreviews); setError('')
  }
  async function compare() {
    if (!files[0] || !files[1]) { setError('Choose both a reference image and a comparison image.'); return }
    setBusy(true); setError('')
    try {
      const form = new FormData(); form.append('comparison', files[1])
      let result
      if (initialReference?.id && !(files[0] instanceof File)) {
        result = await request(`/analysis/compare/${initialReference.id}`, { method: 'POST', body: form })
      } else {
        form.append('reference', files[0])
        result = await request('/analysis/compare', { method: 'POST', body: form })
      }
      result.reference_name = files[0].name; result.comparison_name = files[1].name; result.created_at = new Date().toISOString()
      onCompared(result)
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }
  const latest = comparisons[0]
  return <div className="page subpage"><PageIntro eyebrow="IMAGE COMPARISON" title="Discover the differences" text="Compare photographs to see how their forms and surfaces relate." />
    <div className="compare-cards">{['Reference image', 'Comparison image'].map((label, i) => <div className="compare-card" key={label}><div className="compare-card-heading"><span className="compare-number">0{i + 1}</span><div><b>{label}</b><small>{i === 0 ? 'The image you want to study' : 'Choose an image to compare with'}</small></div></div><button className={`compare-drop ${previews[i] ? 'filled' : ''}`} onClick={() => inputRefs[i].current?.click()}><input ref={inputRefs[i]} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => choose(i, e.target.files[0])} />{previews[i] ? <><img src={previews[i]} alt={label} /><span className="compare-image-name">{files[i]?.name}</span><span className="change-image">Change image</span></> : <><ImagePlus size={22} /><b>Add an image</b><span>JPEG, PNG or WebP · Max 10 MB</span><em>Browse files <ArrowRight size={13} /></em></>}</button></div>)}</div>
    <div className="compare-center"><span className="versus-mark">↔</span><button className="primary-button" disabled={busy} onClick={compare}>{busy ? <><span className="spinner" /> Comparing...</> : <>Compare images <ArrowRight size={16} /></>}</button></div>
    {latest && <div className="panel comparison-result-panel"><div><span className="eyebrow">LATEST VISUAL COMPARISON</span><h3>{latest.reference_name || 'Reference'} <span>and</span> {latest.comparison_name || 'Comparison'}</h3><p>{latest.analysis || 'Image-level comparison results.'}</p>{latest.metrics && <div className="comparison-metrics"><span>Shape and edge layout <b>{Math.round((latest.metrics.structure_similarity || 0) * 100)}%</b></span><span>Horizontal band pattern <b>{Math.round((latest.metrics.horizontal_layer_pattern_similarity || 0) * 100)}%</b></span><span>Vertical shape pattern <b>{Math.round((latest.metrics.vertical_shape_pattern_similarity || 0) * 100)}%</b></span><span>Color appearance <b>{Math.round((latest.metrics.color_similarity || 0) * 100)}%</b></span></div>}</div><div className="compare-score"><strong>{Math.round(latest.similarity * 100)}%</strong><span>pixel similarity</span></div></div>}
    <div className="compare-method"><ShieldCheck size={15} /><span>Scores compare image-level edges, bands, and color. They do not identify named objects such as pillars or gopurams.</span></div>
  </div>
}

function HistoryPage({ rows, onResult, onUpload }) { const [sort, setSort] = useState('newest'); const sorted = [...rows].sort((a, b) => sort === 'oldest' ? new Date(a.created_at) - new Date(b.created_at) : new Date(b.created_at) - new Date(a.created_at)); return <div className="page subpage"><PageIntro eyebrow="PREDICTION HISTORY" title="Your discovery archive" text="Revisit the architectural stories you've explored." action={<button className="primary-button" onClick={onUpload}><Plus size={16} /> New analysis</button>} /><div className="history-toolbar"><div><b>{rows.length}</b> saved analyses</div><label className="sort-select">Sort by <select value={sort} onChange={e => setSort(e.target.value)}><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select><ChevronDown size={14} /></label></div><div className="history-list">{sorted.map((row, i) => <button className="history-card" key={row.id} onClick={() => onResult(row)}><div className="history-number">{String(i + 1).padStart(2, '0')}</div><span className={`history-icon ${categoryInfo[row.architecture]?.color || 'gray'}`}><Landmark size={20} /></span><div className="history-content"><b>{row.filename || 'Temple image'}</b><span>{classLabel(row.architecture)} architecture <i>·</i> {dateLabel(row.created_at)}</span></div><div className="history-confidence"><span>CONFIDENCE</span><b>{((row.confidence || 0) * 100).toFixed(1)}%</b></div><ChevronRight size={17} /></button>)}{!sorted.length && <EmptyState title="Your journal is waiting" text="Your analyzed images will be collected here." action="Start your first analysis" onClick={onUpload} />}</div></div> }

const templeData = [
  { style: 'NAGARA', region: 'Northern India', name: 'The curving skyline', tower: 'Shikhara', description: 'Nagara temples are recognized by their beehive-like, curvilinear tower rising above a square sanctuary. The vertical lines draw the eye toward an amalaka and kalasha crown.', features: ['Curvilinear shikhara', 'Amalaka crown', 'Panchayatana layouts are common'], places: 'Khajuraho · Konark · Modhera', tone: 'saffron' },
  { style: 'DRAVIDA', region: 'Southern India', name: 'The rising pyramid', tower: 'Vimana', description: 'Dravida temples build upward in clearly defined storeys. Enclosure walls and monumental gopurams frame the sanctuary, while sculpted tiers give the complex its distinctive profile.', features: ['Pyramidal, tiered vimana', 'Monumental gopuram gateways', 'Enclosed temple compounds'], places: 'Thanjavur · Madurai · Kanchipuram', tone: 'green' },
  { style: 'VESARA', region: 'Deccan region', name: 'Where traditions meet', tower: 'Deccan forms', description: 'Vesara describes a rich range of Deccan temple forms that bring together northern and southern ideas. Intricate stone carving and inventive plans make each temple distinctly local.', features: ['Blended tower forms', 'Highly articulated plans', 'Intricate stone ornament'], places: 'Pattadakal · Belur · Halebidu', tone: 'blue' },
]
function TemplesPage({ onUpload }) {
  const [active, setActive] = useState('NAGARA')
  const [query, setQuery] = useState('')
  const [matches, setMatches] = useState([])
  const [lookupError, setLookupError] = useState('')
  const item = templeData.find(row => row.style === active)
  useEffect(() => {
    let cancelled = false
    const timer = window.setTimeout(async () => {
      try {
        const result = await request(`/temples?q=${encodeURIComponent(query)}&style=${active}`)
        if (!cancelled) { setMatches(result.items || []); setLookupError('') }
      } catch (err) { if (!cancelled) setLookupError(err.message) }
    }, 180)
    return () => { cancelled = true; window.clearTimeout(timer) }
  }, [query, active])
  return <div className="page subpage"><PageIntro eyebrow="TEMPLE INFORMATION" title="Explore India's temple traditions" text="Search temple records and explore the forms of Indian temple architecture." />
    <label className="temple-search"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search temple, location, or style" aria-label="Search temple information" /></label>
    <div className="temple-tabs">{templeData.map(row => <button key={row.style} className={active === row.style ? 'active' : ''} onClick={() => setActive(row.style)}><span className={`tab-symbol ${row.tone}`}>{categoryInfo[row.style].symbol}</span><span>{classLabel(row.style)}<small>{row.region}</small></span>{active === row.style && <ChevronRight size={15} />}</button>)}</div>
    <div className="temple-search-results"><div className="section-title"><h3>Temple records</h3><span>{matches.length} FOUND</span></div>{lookupError ? <p>{lookupError}</p> : matches.length ? matches.map(record => <article className="temple-search-result" key={record.id}><div><span className="eyebrow">{record.architecture} · {record.details?.period || 'Historic site'}</span><h4>{record.name}</h4><span className="temple-result-location"><Landmark size={14} /> {record.location}</span><p>{record.description}</p>{record.details?.features?.length > 0 && <small>{record.details.features.join(' · ')}</small>}</div>{record.details?.source && <a href={record.details.source} target="_blank" rel="noreferrer">Source <ArrowRight size={13} /></a>}</article>) : <p>No matching records in this style yet.</p>}</div>
    <div className="temple-feature"><div className="temple-feature-visual"><TempleIllustration variant={item.style} /></div><div className="temple-feature-copy"><span className="eyebrow">{item.region.toUpperCase()} · {item.tower.toUpperCase()}</span><h2>{item.name}</h2><p>{item.description}</p><div className="temple-feature-list">{item.features.map(x => <span key={x}><Check size={14} />{x}</span>)}</div><div className="temple-sites"><Landmark size={15} /><span>LOOK FOR IT AT</span><b>{item.places}</b></div><button className="secondary-button" onClick={onUpload}>Analyze a {classLabel(item.style)} temple <ArrowRight size={15} /></button></div></div><p className="field-guide-note"><BookOpen size={14} /> Architectural labels are useful guides, but temple forms vary across time, region, and patronage.</p></div>
}

function ReportsPage({ rows, onReport, onUpload }) {
  const [query, setQuery] = useState('')
  const matches = filtered(rows, query)
  return <div className="page subpage"><PageIntro eyebrow="REPORTS" title="Your research collection" text="Download and manage your temple analysis reports. Keep a record of your discoveries and research in one place." />
    <label className="temple-search report-search"><Search size={16} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search reports..." aria-label="Search reports" /></label>
    {rows.length ? <div className="heritage-report-table"><table><thead><tr><th>Temple image</th><th>Style</th><th>Date analysed</th><th>Actions</th></tr></thead><tbody>{matches.map(row => <tr key={row.id}><td><span className="report-name"><Landmark size={24} /><span><b>{row.filename || 'Temple image'}</b>{String(row.id).startsWith('demo') && <small>Sample</small>}</span></span></td><td><span className={`style-pill ${categoryInfo[row.architecture]?.color || 'gray'}`}>{classLabel(row.architecture)}</span></td><td>{dateLabel(row.created_at)}</td><td><button className="secondary-button" onClick={() => onReport(row)}><ArrowDownToLine size={14} /> View report</button></td></tr>)}</tbody></table>{!matches.length && <p className="report-no-matches">No reports match your search.</p>}</div> : <div className="panel report-empty"><EmptyState title="No reports yet" text="Analyze an image first to create a downloadable report." action="Upload an image" onClick={onUpload} /></div>}
  </div>
}

function ReportPage({ row, setError, flash }) { const [loading, setLoading] = useState(false); async function generate() { if (!row?.id || String(row.id).startsWith('demo')) { setError('Sign in and run a real analysis before generating a report.'); return } setLoading(true); setError(''); try { await request(`/reports/${row.id}`, { method: 'POST' }); await downloadBlob(`/reports/${row.id}/download`, `architecture-analysis-${row.id}.pdf`); flash('Your report is ready to download.') } catch (err) { setError(err.message) } finally { setLoading(false) } } const style = categoryInfo[row?.architecture] || categoryInfo.UNKNOWN; return <div className="page subpage"><PageIntro eyebrow="ANALYSIS REPORT" title="A considered record of your study." text="Generate a shareable PDF with the image, prediction, and analysis notes." /><div className="report-preview"><div className="report-paper"><div className="paper-head"><span><Landmark size={18} /> TEMPLE ATLAS</span><span>FIELD STUDY · 01</span></div><div className="paper-rule"/><div className="paper-image"><TempleIllustration variant={row?.architecture} /></div><span className="eyebrow">ARCHITECTURAL ANALYSIS</span><h2>{row?.filename || 'Temple image'}</h2><div className="paper-tag">{style.title.toUpperCase()} TRADITION</div><div className="paper-info"><div><span>CLASSIFICATION</span><b>{style.title}</b></div><div><span>CONFIDENCE</span><b>{((row?.confidence || 0) * 100).toFixed(1)}%</b></div><div><span>DATE OF STUDY</span><b>{row?.created_at ? dateLabel(row.created_at) : '—'}</b></div></div><p>{row?.analysis || 'No analysis description is available for this item.'}</p><div className="paper-foot"><span>EXPLORE · UNDERSTAND · PRESERVE</span><span>templeatlas</span></div></div><div className="report-preview-aside"><span className="eyebrow">YOUR PDF REPORT</span><h3>Beautifully documented.</h3><p>A clean, printable record of your image analysis for your notes, research, or classroom.</p><ul><li><Check size={15} /> Input image and prediction</li><li><Check size={15} /> Confidence and analysis explanation</li><li><Check size={15} /> Feature-detection status and saved comparisons</li><li><Check size={15} /> Analysis date and time</li></ul><button className="primary-button" disabled={loading} onClick={generate}>{loading ? 'Preparing report...' : <> <ArrowDownToLine size={16} /> Download PDF report</>}</button><small>PDF · Generated from your saved analysis</small></div></div></div> }

function ProfilePage({ user, onLogout, onUserUpdated, flash }) {
  const [email, setEmail] = useState(user?.email || '')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  async function saveEmail(event) {
    event.preventDefault(); setSaving(true); setError('')
    try { const profile = await request('/profile', { method: 'PATCH', body: JSON.stringify({ email }) }); onUserUpdated(profile); flash('Profile updated.') }
    catch (err) { setError(err.message) } finally { setSaving(false) }
  }
  async function savePassword(event) {
    event.preventDefault(); setSaving(true); setError('')
    try { await request('/profile/password', { method: 'POST', body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }) }); onLogout('Password changed. Sign in again with your new password.') }
    catch (err) { setError(err.message); setSaving(false) }
  }
  return <div className="page subpage"><PageIntro eyebrow="YOUR WORKSPACE" title="A little about you." text="Manage your Temple Atlas account and research workspace." />
    <div className="profile-layout"><div className="panel profile-card"><div className="profile-avatar">{(user?.email?.[0] || 'A').toUpperCase()}</div><span className="eyebrow">RESEARCHER PROFILE</span><h2>{user?.email?.split('@')[0] || 'Guest explorer'}</h2><p>{user?.email || 'Preview mode'}</p><div className="profile-divider"/><div className="profile-row"><span>Workspace</span><b>Personal research</b></div><div className="profile-row"><span>Account status</span><b><i className="status-dot green" /> Active</b></div><button className="secondary-button" onClick={() => onLogout()}><LogOut size={15} /> Sign out</button></div>
      <div className="panel settings-card"><span className="eyebrow">ACCOUNT SECURITY</span><h3>Profile and password</h3><form className="profile-form" onSubmit={saveEmail}><label>Email address<input type="email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" /></label><button className="secondary-button" disabled={saving}>Save email</button></form><form className="profile-form" onSubmit={savePassword}><label>Current password<input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required autoComplete="current-password" /></label><label>New password<input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required minLength={8} maxLength={72} autoComplete="new-password" /></label><small>Use at least 8 characters. Changing your password signs out all sessions.</small><button className="primary-button" disabled={saving}>Change password</button></form>{error && <p className="profile-error" role="alert">{error}</p>}<div className="settings-info"><ShieldCheck size={18} /><div><b>Password protection</b><span>Passwords are stored as bcrypt hashes. Existing sessions are invalidated after a password change.</span></div></div></div></div></div>
}
