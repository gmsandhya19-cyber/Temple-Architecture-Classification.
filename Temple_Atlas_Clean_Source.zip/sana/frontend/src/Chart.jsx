import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

const colors = { saffron: '#d88c52', green: '#729176', blue: '#8295a3' }

export default function ArchitectureChart({ data }) {
  return <ResponsiveContainer width="100%" height="100%"><BarChart data={data} margin={{ top: 10, right: 8, left: -22, bottom: 0 }} barSize={34}>
    <CartesianGrid vertical={false} stroke="#eeece5" strokeDasharray="3 4" />
    <XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fill: '#89877f', fontSize: 11 }} dy={10} />
    <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: '#aaa79f', fontSize: 10 }} />
    <Tooltip cursor={{ fill: '#f7f6f2' }} contentStyle={{ border: '1px solid #eeece5', borderRadius: 10, fontSize: 12 }} />
    <Bar dataKey="count" radius={[6, 6, 0, 0]}>{data.map((entry, index) => <Cell key={index} fill={colors[entry.fill]} />)}</Bar>
  </BarChart></ResponsiveContainer>
}
