# Temple Atlas API

FastAPI backend for accounts, temple-image analysis, comparisons, prediction history, and PDF reports. The API listens on `http://127.0.0.1:8000` by default. Interactive documentation is at `/docs`.

## Install and run on Windows

From the repository root:

```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:JWT_SECRET = "replace-with-a-random-secret-at-least-32-characters-long"
uvicorn app.main:app --reload
```

The project-local virtual environment avoids writes to protected global or user Python directories. If PowerShell activation is disabled, run `.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.venv\Scripts\python.exe -m uvicorn app.main:app --reload` instead.

Optional API smoke-test dependencies are in `dev-requirements.txt`:

```powershell
python -m pip install -r dev-requirements.txt
python -m unittest discover -s tests -v
```

## Configuration and data

Copy `.env.example` to `.env` and edit the values. The backend loads this file automatically; existing shell environment variables take precedence. Relative storage paths resolve from the `backend` directory.

| Variable | Default | Description |
| --- | --- | --- |
| `DATABASE_PATH` | `data/architecture.db` | SQLite database |
| `UPLOAD_DIR` | `data/uploads` | Uploaded image storage |
| `REPORT_DIR` | `data/reports` | Generated PDF reports |
| `JWT_SECRET` | Generated at development startup | Use a stable random secret of at least 32 characters in production |
| `JWT_EXPIRE_MINUTES` | `60` | Access-token lifetime |
| `MAX_UPLOAD_MB` | `10` | Maximum upload size |
| `CORS_ORIGINS` | localhost and 127.0.0.1 on port 5173 | Comma-separated frontend origins |
| `ARCHITECTURE_DATASET_DIR` | `../dataset/training` | Training images directory |
| `ARCHITECTURE_MODEL_PATH` | `../data/architecture_model.npz` | Trained model artifact |
| `ENABLE_AI_PART_DETECTION` | `false` | Enable optional Gemini image-grounded part boxes |
| `GEMINI_API_KEY` | empty | Google Gemini API key; required when part detection is enabled |
| `GEMINI_VISION_MODEL` | `gemini-3.5-flash` | Vision model used for part mapping |
| `GEMINI_VISION_TIMEOUT` | `60` | Vision request timeout in seconds |

The API creates these SQLite tables at startup: `users`, `temples`, `uploaded_images`, `predictions`, `architectural_features`, `comparisons`, `prediction_history`, and `revoked_tokens`. Foreign keys are enabled. Passwords are hashed with bcrypt; revoked token hashes are kept in SQLite. Existing databases from earlier backend versions are migrated during startup.

## Train the image classifier

The supplied dataset has 150 images across `NAGARA`, `DRAVIDA`, and `VESARA` (50 per class). The current pipeline corrects EXIF orientation, resizes to 160×160, applies a 3×3 median filter and per-channel autocontrast, then extracts HOG and RGB/HSV histogram features. A NumPy cosine-neighbour classifier runs without scikit-learn's Windows native extensions. From the backend directory, run:

```powershell
.venv\Scripts\python.exe train_model.py
```

Training runs stratified five-fold cross-validation, prints class metrics, and saves a numeric-only `data/architecture_model.npz` artifact at the repository root. The current evaluation is **43.3% accuracy** on this small dataset. The local style model does not detect individual parts; optional AI image mapping is described below.

## API routes

Routes are prefixed with `/api`. All routes except register, login, health, and the temple directory require `Authorization: Bearer <access_token>`.

| Method | Route | Purpose |
| --- | --- | --- |
| `POST` | `/auth/register` | Register with email and password (8–72 characters) |
| `POST` | `/auth/login` | Sign in and receive a token |
| `POST` | `/auth/logout` | Revoke the current token |
| `GET` | `/profile` | Retrieve the signed-in user's profile |
| `PATCH` | `/profile` | Update the account email |
| `POST` | `/profile/password` | Change password and invalidate all existing sessions |
| `POST` | `/analysis/predict` | Multipart `image`; predict and save to history |
| `POST` | `/analysis/compare` | Multipart `reference` and `comparison` images |
| `POST` | `/analysis/compare/{prediction_id}` | Compare an uploaded image with an owned saved prediction image |
| `GET` | `/temples?q=...&style=...` | Search the seeded temple reference directory |
| `GET` | `/history` | List own analyses (`limit` 1–100, `offset`) |
| `GET` | `/history/{prediction_id}` | Retrieve one owned analysis |
| `GET` | `/history/{prediction_id}/image` | Retrieve its protected image |
| `GET` | `/comparisons` | List own saved comparisons |
| `POST` | `/reports/{prediction_id}` | Generate a PDF report |
| `GET` | `/reports/{prediction_id}/download` | Download the generated PDF |
| `GET` | `/health` | Health check |

Uploads accept JPEG, PNG, and WebP. Comparison results include normalized pixel, edge/shape, horizontal/vertical edge-pattern, and color-histogram scores. These image-level measurements do not identify named objects such as pillars or gopurams.

The API seeds a small searchable temple directory with source links on first launch. It is a reference guide, not automatic temple recognition. The current SQLite database remains the configured storage engine, matching the earlier project database requirement; the architecture diagram's MySQL box is not implemented.

The style prediction remains a HOG + RGB/HSV histogram cosine-neighbour classifier and has about 43.3% cross-validation accuracy on the supplied 150 images. Optional part mapping uses Gemini image understanding and structured JSON output to propose normalized bounding boxes for visible, style-specific terms. It is disabled by default. To enable it, set `ENABLE_AI_PART_DETECTION=true` and add `GEMINI_API_KEY` in `backend/.env`. Each image-analysis upload is then sent to Google for visual processing; API usage may incur charges. Keep it disabled if you do not want uploads sent to an external service. Boxes are AI estimates and should be reviewed; the project has no annotated temple-part dataset for model-specific training or accuracy evaluation. The API omits parts it cannot identify, and does not fabricate fallback coordinates. Image preprocessing for the local style classifier includes resizing, median noise reduction, contrast enhancement, and grayscale normalization; semantic background removal is not used.

## Verification

From the repository root, Python syntax can be checked with:

```powershell
backend\.venv\Scripts\python.exe -m py_compile backend\app\main.py backend\app\model.py backend\train_model.py
```

For production, configure a strong stable secret, use HTTPS, and place the SQLite database, uploads, and reports on persistent storage.

## Retrying AI part mapping

Mapping retries temporary network, rate-limit and server errors once per model, then tries `GEMINI_VISION_FALLBACK_MODELS` (comma-separated; default `gemini-3.1-flash-lite`). The primary model is `gemini-3.5-flash`. Each attempt uses `GEMINI_VISION_TIMEOUT`, capped at 20 seconds. The primary and fallback each get one attempt, normally limiting provider waits to about 40 seconds during an outage. Socket timeouts are not a strict total wall-clock deadline. Authentication failures are not retried.

Open an analysis and click **Retry AI mapping** to map its saved photo without another upload. This calls `POST /api/history/{prediction_id}/parts`; ownership is required, successful results are saved, and temporary failures preserve existing boxes. New uploads attempt mapping automatically when enabled. A successful request can return no boxes when no parts are confidently visible.
