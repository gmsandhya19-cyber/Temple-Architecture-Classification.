"""Train the architecture classifier: python train_model.py"""
import json

from app.model import train_model


if __name__ == "__main__":
    metrics = train_model()
    print(json.dumps(metrics, indent=2))
