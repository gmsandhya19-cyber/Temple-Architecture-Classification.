"""Train and run the temple-style image classifier using NumPy and scikit-image."""
from __future__ import annotations

import os
from pathlib import Path
from threading import RLock

from PIL import Image, ImageFilter, ImageOps


ROOT = Path(__file__).resolve().parents[2]


def _configured_path(name: str, default: Path) -> Path:
    path = Path(os.getenv(name, str(default)))
    return (ROOT / "backend" / path).resolve() if not path.is_absolute() else path.resolve()


DATASET_DIR = _configured_path("ARCHITECTURE_DATASET_DIR", ROOT / "dataset" / "training")
MODEL_PATH = _configured_path("ARCHITECTURE_MODEL_PATH", ROOT / "data" / "architecture_model.npz")
MODEL_VERSION = "hog-color-prototype-v1"
_lock = RLock()
_cached_model: dict | None = None


def _feature_dependencies():
    try:
        import numpy as np
        from skimage.feature import hog
    except (ImportError, OSError) as exc:
        raise RuntimeError(f"Image feature runtime unavailable: {exc}") from exc
    return np, hog


def extract_features(image: Image.Image):
    np, hog = _feature_dependencies()
    image = ImageOps.exif_transpose(image).convert("RGB").resize((160, 160))
    image = ImageOps.autocontrast(image.filter(ImageFilter.MedianFilter(size=3)))
    rgb = np.asarray(image, dtype=np.uint8)
    hsv = np.asarray(image.convert("HSV"), dtype=np.uint8)
    color = np.concatenate([
        np.histogram(rgb[:, :, channel], bins=16, range=(0, 256), density=True)[0]
        for channel in range(3)
    ] + [
        np.histogram(hsv[:, :, channel], bins=16, range=(0, 256), density=True)[0]
        for channel in range(3)
    ])
    gray = np.asarray(image.convert("L"), dtype=np.float32) / 255.0
    texture = hog(gray, orientations=9, pixels_per_cell=(16, 16), cells_per_block=(2, 2),
                  block_norm="L2-Hys", feature_vector=True)
    return np.concatenate([texture, color]).astype(np.float32)


def load_training_data(dataset_dir: Path | None = None):
    np, _ = _feature_dependencies()
    dataset_dir = Path(dataset_dir or DATASET_DIR)
    if not dataset_dir.is_dir():
        raise RuntimeError(f"Training dataset was not found: {dataset_dir}")
    features, labels, files = [], [], []
    valid = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    for class_dir in sorted(path for path in dataset_dir.iterdir() if path.is_dir()):
        for path in sorted(path for path in class_dir.iterdir() if path.is_file() and path.suffix.lower() in valid):
            try:
                with Image.open(path) as image:
                    features.append(extract_features(image))
                labels.append(class_dir.name.upper())
                files.append(str(path))
            except (OSError, ValueError) as exc:
                print(f"Skipping unreadable image {path}: {exc}")
    if not features:
        raise RuntimeError(f"No readable images found under {dataset_dir}")
    classes, counts = np.unique(labels, return_counts=True)
    if len(classes) < 2 or int(np.min(counts)) < 2:
        raise RuntimeError("Training requires at least two classes and two images per class")
    return np.stack(features), np.asarray(labels), files


def _normalized_rows(features):
    np, _ = _feature_dependencies()
    norms = np.linalg.norm(features, axis=1, keepdims=True)
    return features / np.maximum(norms, 1e-8)


def _probabilities(query_features, train_features, train_labels, classes):
    """Use a weighted cosine-neighbour vote without a compiled sklearn runtime."""
    np, _ = _feature_dependencies()
    queries = _normalized_rows(query_features)
    references = _normalized_rows(train_features)
    similarities = np.clip(queries @ references.T, -1.0, 1.0)
    class_scores = []
    for label in classes:
        class_similarities = np.sort(similarities[:, train_labels == label], axis=1)[:, -min(5, int(np.sum(train_labels == label))):]
        class_scores.append(np.mean(class_similarities, axis=1))
    scores = np.stack(class_scores, axis=1)
    # Similarities cluster in a narrow range; temperature makes neighbours useful votes.
    logits = (scores - scores.max(axis=1, keepdims=True)) / 0.035
    weights = np.exp(np.clip(logits, -60, 0))
    return weights / np.maximum(weights.sum(axis=1, keepdims=True), 1e-12)


def train_model(dataset_dir: Path | None = None, model_path: Path | None = None) -> dict:
    np, _ = _feature_dependencies()
    dataset_dir = Path(dataset_dir or DATASET_DIR)
    model_path = Path(model_path or MODEL_PATH)
    features, labels, _ = load_training_data(dataset_dir)
    classes, counts = np.unique(labels, return_counts=True)
    fold_count = min(5, int(counts.min()))
    rng = np.random.default_rng(42)
    folds = [[] for _ in range(fold_count)]
    for label in classes:
        indices = np.flatnonzero(labels == label)
        rng.shuffle(indices)
        for position, index in enumerate(indices):
            folds[position % fold_count].append(int(index))
    predicted = np.empty_like(labels)
    confusion = np.zeros((len(classes), len(classes)), dtype=np.int64)
    class_index = {label: index for index, label in enumerate(classes)}
    for fold in folds:
        validation = np.asarray(fold, dtype=int)
        training = np.setdiff1d(np.arange(len(labels)), validation, assume_unique=False)
        probabilities = _probabilities(features[validation], features[training], labels[training], classes)
        predicted[validation] = classes[np.argmax(probabilities, axis=1)]
        for actual, estimate in zip(labels[validation], predicted[validation]):
            confusion[class_index[actual], class_index[estimate]] += 1
    accuracy = float(np.mean(predicted == labels))
    report = {}
    for index, label in enumerate(classes):
        true_positive = int(confusion[index, index])
        precision = true_positive / max(1, int(confusion[:, index].sum()))
        recall = true_positive / max(1, int(confusion[index, :].sum()))
        report[str(label)] = {"precision": precision, "recall": recall,
                              "f1-score": 2 * precision * recall / max(precision + recall, 1e-12),
                              "support": int(confusion[index, :].sum())}
    evaluation = {
        "evaluation": f"{fold_count}-fold stratified cross-validation",
        "accuracy": accuracy,
        "classification_report": report,
        "confusion_matrix": confusion.tolist(),
        "confusion_matrix_labels": classes.tolist(),
        "image_count": int(len(labels)),
        "class_counts": {str(label): int(count) for label, count in zip(classes, counts)},
    }
    model_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = model_path.with_suffix(".tmp.npz")
    np.savez_compressed(temporary, features=features, labels=labels, classes=classes,
                        version=np.asarray(MODEL_VERSION), evaluation=np.asarray(accuracy))
    temporary.replace(model_path)
    global _cached_model
    with _lock:
        _cached_model = {"features": features, "labels": labels, "classes": classes,
                         "version": MODEL_VERSION, "evaluation": evaluation}
    return evaluation


def _load_model() -> dict | None:
    global _cached_model
    if _cached_model is not None:
        return _cached_model
    with _lock:
        if _cached_model is not None:
            return _cached_model
        np, _ = _feature_dependencies()
        if MODEL_PATH.is_file():
            try:
                with np.load(MODEL_PATH, allow_pickle=False) as stored:
                    if str(stored["version"].item()) == MODEL_VERSION:
                        _cached_model = {"features": stored["features"], "labels": stored["labels"],
                                         "classes": stored["classes"], "version": MODEL_VERSION,
                                         "evaluation": {"accuracy": float(stored["evaluation"].item())}}
                        return _cached_model
            except (OSError, ValueError, KeyError):
                pass
        train_model()
        return _cached_model


def predict_image(image: Image.Image) -> dict | None:
    np, _ = _feature_dependencies()
    artifact = _load_model()
    if artifact is None:
        return None
    features = extract_features(image).reshape(1, -1)
    probabilities = _probabilities(features, artifact["features"], artifact["labels"], artifact["classes"])[0]
    winner = int(np.argmax(probabilities))
    architecture = str(artifact["classes"][winner])
    confidence = float(probabilities[winner])
    ranked = sorted(zip(artifact["classes"], probabilities), key=lambda pair: pair[1], reverse=True)
    alternatives = [{"architecture": str(label), "confidence": round(float(score), 4)} for label, score in ranked]
    confidence_note = "moderate" if confidence >= 0.60 else "low"
    analysis = (f"The image is most consistent with {architecture.title()} architecture "
                f"({confidence:.1%} model confidence). This is a {confidence_note}-confidence prediction "
                "from a small, image-only training set; verify against architectural details and historical context.")
    return {"architecture": architecture, "confidence": confidence, "analysis": analysis,
            "model": artifact.get("version", MODEL_VERSION), "classified": True,
            "alternatives": alternatives}
