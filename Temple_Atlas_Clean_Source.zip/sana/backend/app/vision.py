"""Optional image-grounded temple-part mapping through Google's Gemini API."""
from __future__ import annotations

import base64
import io
import json
import os
from urllib.parse import quote
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from PIL import Image


def _setting(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


STYLE_TERMS = {
    "NAGARA": [
        "Kalasa", "Amalaka", "Griva", "Shikhara", "Urushringa", "Karna",
        "Jangha", "Mandapa", "Ardhamandapa", "Mahamandapa", "Antarala",
        "Garbhagriha", "Jagati", "Adhisthana", "Sukanasika", "Chandrika",
    ],
    "DRAVIDA": [
        "Stupi", "Kalasa", "Shikhara", "Vimana", "Griva", "Tala", "Kapota",
        "Hara", "Kuta", "Sala", "Kudu", "Prastara", "Pada", "Mandapa",
        "Antarala", "Garbhagriha", "Jagati", "Adhisthana",
    ],
    "VESARA": [
        "Kalasa", "Amalaka", "Griva", "Shikhara", "Vimana", "Tala", "Kapota",
        "Karna", "Jangha", "Mandapa", "Antarala", "Garbhagriha", "Jagati",
        "Adhisthana",
    ],
}


def _schema(terms: list[str]) -> dict:
    return {
        "type": "object",
        "properties": {
            "parts": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "enum": terms},
                        "x1": {"type": "integer"},
                        "y1": {"type": "integer"},
                        "x2": {"type": "integer"},
                        "y2": {"type": "integer"},
                        "evidence": {"type": "string"},
                    },
                    "required": ["name", "x1", "y1", "x2", "y2", "evidence"],
                    "additionalProperties": False,
                },
            },
            "note": {"type": "string"},
        },
        "required": ["parts", "note"],
        "additionalProperties": False,
    }


def detect_parts(image: Image.Image, architecture: str) -> tuple[list[dict], str, str | None]:
    """Return style-constrained normalized boxes. No fabricated fallback boxes are created."""
    enabled = _setting("ENABLE_AI_PART_DETECTION", "false").lower() in {"1", "true", "yes", "on"}
    api_key = _setting("GEMINI_API_KEY")
    if not enabled or not api_key:
        return [], "not_configured", None
    terms = STYLE_TERMS.get(architecture)
    if not terms:
        return [], "unsupported_style", None

    # Normalize EXIF orientation/format, keeping coordinate space identical to the preview.
    normalized = image.convert("RGB")
    normalized.thumbnail((1536, 1536))
    buffer = io.BytesIO()
    normalized.save(buffer, format="JPEG", quality=88, optimize=True)
    image_base64 = base64.b64encode(buffer.getvalue()).decode("ascii")
    model = _setting("GEMINI_VISION_MODEL", "gemini-3.1-flash-lite")
    schema = _schema(terms)
    prompt = (
        f"Inspect this real temple photograph. The style classifier predicted {architecture.title()}. "
        f"Use only these tradition-appropriate part names: {', '.join(terms)}. "
        "Return tight bounding boxes only for parts that are visibly present and visually identifiable "
        "in this specific image. Do not infer hidden/interior parts (for example, a garbhagriha from an "
        "exterior), do not label generic regions just because their usual position is known, and do not "
        "invent a box when uncertain. Coordinates are integer values from 0 through 1000, normalized "
        "independently to the full upright image width and height: x1,y1 is top-left and x2,y2 bottom-right. "
        "Make each box tight around the visible architectural element. If this is not a temple image or "
        "the part cannot be identified, return an empty parts list and explain briefly in note. "
        "Do not mark text, watermarks, people, vegetation, or the whole building as an architectural part."
    )
    payload = {
        "contents": [{"role": "user", "parts": [
            {"text": prompt},
            {"inline_data": {"mime_type": "image/jpeg", "data": image_base64}},
        ]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseJsonSchema": schema,
            "maxOutputTokens": 8192,
            "temperature": 0,
        },
    }
    models = list(dict.fromkeys([model] + [value.strip() for value in
        _setting("GEMINI_VISION_FALLBACK_MODELS", "gemini-3.5-flash").split(",") if value.strip()]))
    body = None
    quota_limited = False
    last_error = "The vision service is temporarily unavailable. Please retry mapping."
    for candidate_model in models:
        for attempt in range(1):
            request = Request(
                f"https://generativelanguage.googleapis.com/v1beta/models/{quote(candidate_model, safe='-._')}:generateContent",
                data=json.dumps(payload).encode("utf-8"),
                headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urlopen(request, timeout=min(20, max(5, int(_setting("GEMINI_VISION_TIMEOUT", "20"))))) as response:
                    body = json.loads(response.read().decode("utf-8"))
                break
            except HTTPError as exc:
                code = exc.code
                quota_limited = quota_limited or code == 429
                exc.close()
                if code in {401, 403}:
                    return [], "unavailable", "Gemini rejected access. Check the API key and its permissions."
                if code not in {408, 429, 500, 502, 503, 504}:
                    last_error = f"Gemini model request failed (HTTP {code}). Check model configuration."
                    break
                last_error = ("Gemini is temporarily busy or rate-limited. Both model attempts failed; "
                              "please retry mapping shortly.")
            except TimeoutError:
                last_error = "Gemini took too long to respond. Please retry mapping."
            except (URLError, OSError):
                last_error = "Could not connect to Gemini. Check your internet connection and retry mapping."
            except ValueError:
                last_error = "Gemini returned an unreadable response. Please retry mapping."
        if body is not None:
            break
    if body is None:
        if quota_limited:
            last_error = "Gemini quota or rate limit reached, and no fallback completed. Wait for the limit to reset or check your Google AI Studio quota and billing."
        return [], "unavailable", last_error

    if not isinstance(body, dict):
        return [], "unavailable", "Gemini returned an unreadable result."
    candidates = body.get("candidates", [])
    if not isinstance(candidates, list) or (candidates and not isinstance(candidates[0], dict)):
        return [], "unavailable", "Gemini returned an unreadable result."
    content = candidates[0].get("content") if candidates else None
    if not isinstance(content, dict) or not isinstance(content.get("parts"), list):
        return [], "unavailable", "Gemini returned an unreadable result."
    response_parts = content["parts"]
    output_text = "".join(part["text"] for part in response_parts
                          if isinstance(part, dict) and isinstance(part.get("text"), str))
    try:
        result = json.loads(output_text or "")
    except (json.JSONDecodeError, TypeError):
        return [], "unavailable", "Gemini returned an unreadable result."

    if not isinstance(result, dict) or not isinstance(result.get("parts"), list):
        return [], "unavailable", "Gemini returned an unreadable result."

    found = []
    for part in result.get("parts", []):
        if not isinstance(part, dict) or part.get("name") not in terms:
            continue
        coords = [part.get(key) for key in ("x1", "y1", "x2", "y2")]
        if any(not isinstance(value, int) or not 0 <= value <= 1000 for value in coords):
            continue
        x1, y1, x2, y2 = coords
        if x2 <= x1 or y2 <= y1 or x2 - x1 < 3 or y2 - y1 < 3:
            continue
        found.append({"name": part["name"], "bbox": coords,
                      "evidence": str(part.get("evidence", ""))[:180]})
    return found, "available" if found else "no_visible_parts", str(result.get("note", ""))[:300]
