from __future__ import annotations

import io
import hashlib
import json
import os
import secrets
import sqlite3
import textwrap
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Annotated
import unicodedata

import jwt
import bcrypt
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.concurrency import run_in_threadpool
from PIL import Image, ImageChops, ImageFilter, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, EmailStr, Field, field_validator
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from app.model import predict_image
from app.vision import detect_parts


BASE_DIR = Path(__file__).resolve().parents[1]


def configured_path(environment_name: str, default: Path) -> Path:
    value = Path(os.getenv(environment_name, str(default)))
    return (BASE_DIR / value).resolve() if not value.is_absolute() else value.resolve()


def stored_path(value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (BASE_DIR / path).resolve()


DATABASE_PATH = configured_path("DATABASE_PATH", BASE_DIR / "data" / "architecture.db")
UPLOAD_DIR = configured_path("UPLOAD_DIR", BASE_DIR / "data" / "uploads")
REPORT_DIR = configured_path("REPORT_DIR", BASE_DIR / "data" / "reports")
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "60"))
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024 * 1024
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
ARCHITECTURES = ("NAGARA", "DRAVIDA", "VESARA")

app = FastAPI(title="Architecture Analysis API", version="1.0.0")
cors_origins = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=cors_origins, allow_credentials=True,
                   allow_methods=["GET", "POST", "PATCH", "OPTIONS"], allow_headers=["Authorization", "Content-Type"])


@contextmanager
def connection():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DATABASE_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS temples (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, architecture TEXT,
    location TEXT, description TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS uploaded_images (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    temple_id TEXT REFERENCES temples(id) ON DELETE SET NULL,
    original_filename TEXT NOT NULL, storage_path TEXT NOT NULL,
    mime_type TEXT NOT NULL, file_size INTEGER NOT NULL CHECK(file_size > 0),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS predictions (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    uploaded_image_id TEXT NOT NULL REFERENCES uploaded_images(id) ON DELETE CASCADE,
    architecture TEXT NOT NULL, confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
    analysis TEXT NOT NULL, model_version TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS architectural_features (
    id TEXT PRIMARY KEY, prediction_id TEXT NOT NULL REFERENCES predictions(id) ON DELETE CASCADE,
    feature_name TEXT NOT NULL, feature_value TEXT NOT NULL,
    confidence REAL CHECK(confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
    created_at TEXT NOT NULL, UNIQUE(prediction_id, feature_name)
);
CREATE TABLE IF NOT EXISTS comparisons (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reference_image_id TEXT NOT NULL REFERENCES uploaded_images(id) ON DELETE CASCADE,
    comparison_image_id TEXT NOT NULL REFERENCES uploaded_images(id) ON DELETE CASCADE,
    similarity REAL NOT NULL CHECK(similarity >= 0 AND similarity <= 1),
    analysis TEXT NOT NULL, created_at TEXT NOT NULL, metrics_json TEXT NOT NULL DEFAULT '{}',
    CHECK(reference_image_id != comparison_image_id)
);
CREATE TABLE IF NOT EXISTS prediction_history (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    prediction_id TEXT NOT NULL REFERENCES predictions(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS revoked_tokens (
    token_hash TEXT PRIMARY KEY, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS prediction_user_date ON prediction_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS images_user_date ON uploaded_images(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS comparisons_user_date ON comparisons(user_id, created_at DESC);
"""


def initialize_database() -> None:
    with connection() as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            for statement in SCHEMA_SQL.split(";"):
                if statement.strip():
                    db.execute(statement)
            # Migrate databases created by earlier backend revisions.
            columns = {row["name"] for row in db.execute("PRAGMA table_info(users)")}
            if "updated_at" not in columns:
                db.execute("ALTER TABLE users ADD COLUMN updated_at TEXT")
                db.execute("UPDATE users SET updated_at=created_at WHERE updated_at IS NULL")
            if "session_version" not in columns:
                db.execute("ALTER TABLE users ADD COLUMN session_version INTEGER NOT NULL DEFAULT 0")
            temple_columns = {row["name"] for row in db.execute("PRAGMA table_info(temples)")}
            if "details_json" not in temple_columns:
                db.execute("ALTER TABLE temples ADD COLUMN details_json TEXT NOT NULL DEFAULT '{}'")
            comparison_columns = {row["name"] for row in db.execute("PRAGMA table_info(comparisons)")}
            if "metrics_json" not in comparison_columns:
                db.execute("ALTER TABLE comparisons ADD COLUMN metrics_json TEXT NOT NULL DEFAULT '{}'")
            prediction_columns = {row["name"] for row in db.execute("PRAGMA table_info(predictions)")}
            if "uploaded_image_id" not in prediction_columns:
                db.execute("ALTER TABLE predictions RENAME TO predictions_legacy")
                db.execute("""CREATE TABLE predictions (
                id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                uploaded_image_id TEXT NOT NULL REFERENCES uploaded_images(id) ON DELETE CASCADE,
                architecture TEXT NOT NULL, confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                analysis TEXT NOT NULL, model_version TEXT NOT NULL, created_at TEXT NOT NULL)""")
                legacy = db.execute("SELECT * FROM predictions_legacy").fetchall()
                for row in legacy:
                    image_id = str(uuid.uuid4())
                    filename = row["filename"]
                    image_path = row["image_path"]
                    mime_type = "image/jpeg"
                    suffix = Path(filename).suffix.lower()
                    if suffix == ".png": mime_type = "image/png"
                    elif suffix == ".webp": mime_type = "image/webp"
                    file_size = Path(image_path).stat().st_size if Path(image_path).is_file() else 1
                    db.execute("INSERT INTO uploaded_images VALUES(?,?,?,?,?,?,?,?)",
                           (image_id, row["user_id"], None, filename, image_path, mime_type, file_size, row["created_at"]))
                    db.execute("INSERT INTO predictions VALUES(?,?,?,?,?,?,?,?)",
                           (row["id"], row["user_id"], image_id, row["architecture"], row["confidence"],
                            row["analysis"], "legacy", row["created_at"]))
                    db.execute("INSERT INTO prediction_history VALUES(?,?,?,?)",
                           (str(uuid.uuid4()), row["user_id"], row["id"], row["created_at"]))
                db.execute("DROP TABLE predictions_legacy")
            seed_temple_directory(db)
        except Exception:
            db.rollback()
            raise


@app.on_event("startup")
def startup() -> None:
    global JWT_SECRET
    if len(JWT_SECRET) < 32:
        if os.getenv("ENVIRONMENT", "development").lower() == "production":
            raise RuntimeError("Set JWT_SECRET to a random value of at least 32 characters in production")
        JWT_SECRET = secrets.token_urlsafe(48)
        print("WARNING: Generated an ephemeral JWT secret; users will need to sign in again after restart.")
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    initialize_database()


def seed_temple_directory(db: sqlite3.Connection) -> None:
    """Keep a small, searchable reference directory available on first launch."""
    now = datetime.now(timezone.utc).isoformat()
    records = [
        ("khajuraho-group", "Khajuraho Group of Monuments", "NAGARA", "Madhya Pradesh, India",
         "A major group of northern Indian temples built under the Chandella dynasty, mainly during the 10th and 11th centuries.",
         {"period": "10th–11th century CE", "features": ["Nagara temple architecture", "Sculpted temple surfaces"],
          "source": "https://whc.unesco.org/en/list/240"}),
        ("brihadisvara-thanjavur", "Brihadisvara Temple, Thanjavur", "DRAVIDA", "Thanjavur, Tamil Nadu, India",
         "An important Chola-period temple within the Great Living Chola Temples World Heritage property.",
         {"period": "11th century CE", "features": ["Dravida temple architecture", "Chola-period stone temple"],
          "source": "https://whc.unesco.org/en/list/250"}),
        ("pattadakal-group", "Group of Monuments at Pattadakal", "VESARA", "Pattadakal, Karnataka, India",
         "A Chalukya-era temple group noted for a blend of northern and southern architectural forms; Vesara is used here as a broad Deccan classification.",
         {"period": "7th–8th century CE", "features": ["Deccan temple architecture", "Northern and southern forms"],
          "source": "https://whc.unesco.org/en/list/239"}),
    ]
    for temple_id, name, architecture, location, description, details in records:
        db.execute("""INSERT OR IGNORE INTO temples
            (id,name,architecture,location,description,created_at,updated_at,details_json)
            VALUES(?,?,?,?,?,?,?,?)""",
            (temple_id, name, architecture, location, description, now, now, json.dumps(details)))


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)

    @field_validator("password")
    @classmethod
    def password_fits_bcrypt(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("Password must be no more than 72 UTF-8 bytes")
        return value


class ProfileUpdate(BaseModel):
    email: EmailStr


class PasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=72)
    new_password: str = Field(min_length=8, max_length=72)

    @field_validator("new_password")
    @classmethod
    def new_password_fits_bcrypt(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("Password must be no more than 72 UTF-8 bytes")
        return value


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("ascii")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("ascii"))
    except (ValueError, UnicodeEncodeError):
        return False


def make_token(user_id: str, session_version: int = 0) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": user_id, "sv": session_version, "jti": str(uuid.uuid4()), "iat": now, "exp": now + timedelta(minutes=JWT_EXPIRE_MINUTES)}, JWT_SECRET, algorithm=JWT_ALGORITHM)


from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
bearer = HTTPBearer(auto_error=False)


def bearer_user(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]) -> dict:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Bearer token required", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token", headers={"WWW-Authenticate": "Bearer"})
    token_hash = hashlib.sha256(credentials.credentials.encode("utf-8")).hexdigest()
    with connection() as db:
        revoked = db.execute("SELECT 1 FROM revoked_tokens WHERE token_hash=? AND expires_at>?",
                             (token_hash, datetime.now(timezone.utc).isoformat())).fetchone()
    if revoked:
        raise HTTPException(status_code=401, detail="Token has been revoked", headers={"WWW-Authenticate": "Bearer"})
    with connection() as db:
        row = db.execute("SELECT id,email,session_version FROM users WHERE id=?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="User no longer exists")
    if int(payload.get("sv", 0)) != int(row["session_version"]):
        raise HTTPException(status_code=401, detail="Session was invalidated; please sign in again")
    return dict(row)


@app.post("/api/auth/register", status_code=201)
def register(body: Credentials):
    user_id = str(uuid.uuid4())
    try:
        with connection() as db:
            now = datetime.now(timezone.utc).isoformat()
            db.execute("INSERT INTO users(id,email,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)",
                       (user_id, body.email.lower(), hash_password(body.password), now, now))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    return {"user": {"id": user_id, "email": body.email.lower()}, "access_token": make_token(user_id), "token_type": "bearer"}


@app.post("/api/auth/login")
def login(body: Credentials):
    with connection() as db:
        row = db.execute("SELECT id,email,password_hash,session_version FROM users WHERE email=?", (body.email.lower(),)).fetchone()
    if row is None or not verify_password(body.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {"user": {"id": row["id"], "email": row["email"]}, "access_token": make_token(row["id"], row["session_version"]), "token_type": "bearer"}


@app.get("/api/profile")
def get_profile(user: Annotated[dict, Depends(bearer_user)]):
    with connection() as db:
        row = db.execute("SELECT id,email,created_at,updated_at FROM users WHERE id=?", (user["id"],)).fetchone()
    return dict(row)


@app.patch("/api/profile")
def update_profile(body: ProfileUpdate, user: Annotated[dict, Depends(bearer_user)]):
    email = body.email.lower()
    now = datetime.now(timezone.utc).isoformat()
    try:
        with connection() as db:
            db.execute("UPDATE users SET email=?,updated_at=? WHERE id=?", (email, now, user["id"]))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    return {"id": user["id"], "email": email, "updated_at": now}


@app.post("/api/profile/password")
def change_password(body: PasswordChange, user: Annotated[dict, Depends(bearer_user)]):
    with connection() as db:
        row = db.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
        if row is None or not verify_password(body.current_password, row["password_hash"]):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        now = datetime.now(timezone.utc).isoformat()
        db.execute("UPDATE users SET password_hash=?,session_version=session_version+1,updated_at=? WHERE id=?",
                   (hash_password(body.new_password), now, user["id"]))
    return {"message": "Password changed. Sign in again with your new password."}


@app.post("/api/auth/logout")
def logout(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)], _: Annotated[dict, Depends(bearer_user)]):
    if credentials:
        try:
            expires_at = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])["exp"]
            if isinstance(expires_at, (int, float)):
                expires_at = datetime.fromtimestamp(expires_at, timezone.utc).isoformat()
        except (jwt.PyJWTError, KeyError, TypeError, ValueError):
            expires_at = (datetime.now(timezone.utc) + timedelta(minutes=JWT_EXPIRE_MINUTES)).isoformat()
        token_hash = hashlib.sha256(credentials.credentials.encode("utf-8")).hexdigest()
        with connection() as db:
            db.execute("INSERT OR REPLACE INTO revoked_tokens(token_hash,expires_at,created_at) VALUES(?,?,?)",
                       (token_hash, expires_at, datetime.now(timezone.utc).isoformat()))
    return {"message": "Logged out"}


def decode_image(data: bytes) -> Image.Image:
    """Validate headers before allocating memory for decoded pixels."""
    try:
        with Image.open(io.BytesIO(data)) as opened:
            if opened.format not in ALLOWED_FORMATS:
                raise HTTPException(status_code=415, detail="Supported image formats: JPEG, PNG, WEBP")
            if opened.width < 32 or opened.height < 32:
                raise HTTPException(status_code=422, detail="Image dimensions must be at least 32 by 32 pixels")
            if opened.width * opened.height > 40_000_000:
                raise HTTPException(status_code=413, detail="Image dimensions are too large")
            opened.verify()
        with Image.open(io.BytesIO(data)) as source:
            return ImageOps.exif_transpose(source).convert("RGB")
    except Image.DecompressionBombError:
        raise HTTPException(status_code=413, detail="Image dimensions are too large")
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(status_code=415, detail="File is not a valid supported image")


async def read_image(upload: UploadFile) -> tuple[bytes, Image.Image]:
    if not upload.filename:
        raise HTTPException(status_code=400, detail="A filename is required")
    data = await upload.read(MAX_UPLOAD_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded image is empty")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"Image exceeds {MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit")
    image = await run_in_threadpool(decode_image, data)
    return data, image


def analyze_image(image: Image.Image) -> dict:
    """Classify style locally and optionally locate visible parts with image AI."""
    try:
        result = predict_image(image)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if result is not None:
        result["image_dimensions"] = {"width": image.width, "height": image.height}
        result["features"] = {}
        parts, status, note = detect_parts(image, result["architecture"])
        result["parts"] = parts
        result["feature_detection_status"] = status
        result["parts_note"] = note
        result["preprocessing"] = ["EXIF orientation correction", "RGB conversion", "160 × 160 resize", "3 × 3 median noise reduction", "per-channel contrast enhancement", "grayscale normalization", "HOG shape and texture descriptors", "RGB/HSV color histograms"]
        return result
    return {
        "architecture": "UNKNOWN",
        "confidence": 0.0,
        "analysis": "The classifier has not been trained yet. Run `python train_model.py` from the backend directory.",
        "model": "unconfigured",
        "classified": False,
        "training_data_available": Path(__file__).resolve().parents[2].joinpath("dataset", "training").is_dir(),
        "features": {},
        "parts": [],
        "feature_detection_status": "not_available",
        "preprocessing": ["EXIF orientation correction", "RGB conversion", "160 × 160 resize", "3 × 3 median noise reduction", "per-channel contrast enhancement", "grayscale normalization", "HOG shape and texture descriptors", "RGB/HSV color histograms"],
        "image_dimensions": {"width": image.width, "height": image.height},
    }


def save_prediction(user_id: str, filename: str, data: bytes, result: dict, mime_type: str = "image/jpeg") -> str:
    prediction_id = str(uuid.uuid4())
    image_id = str(uuid.uuid4())
    safe_name = Path(filename).name[:120] or "upload"
    image_path = (UPLOAD_DIR / f"{prediction_id}_{safe_name}").resolve()
    image_path.write_bytes(data)
    now = datetime.now(timezone.utc).isoformat()
    with connection() as db:
        db.execute("INSERT INTO uploaded_images VALUES(?,?,?,?,?,?,?,?)",
                   (image_id, user_id, None, safe_name, str(image_path), mime_type, len(data), now))
        db.execute("INSERT INTO predictions VALUES(?,?,?,?,?,?,?,?)",
                   (prediction_id, user_id, image_id, result["architecture"], result["confidence"],
                    result["analysis"], result.get("model", "unconfigured"), now))
        db.execute("INSERT INTO prediction_history VALUES(?,?,?,?)",
                   (str(uuid.uuid4()), user_id, prediction_id, now))
        for feature_name, feature_value in result.get("features", {}).items():
            db.execute("INSERT INTO architectural_features VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), prediction_id, feature_name, str(feature_value), None, now))
        part_counts = {}
        for part in result.get("parts", []):
            part_counts[part["name"]] = part_counts.get(part["name"], 0) + 1
            stored_name = part["name"] if part_counts[part["name"]] == 1 else f"{part['name']} {part_counts[part['name']]}"
            db.execute("INSERT OR REPLACE INTO architectural_features VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), prediction_id, stored_name,
                        json.dumps({"bbox": part["bbox"], "evidence": part.get("evidence", "")}), None, now))
        if "feature_detection_status" in result:
            db.execute("INSERT OR REPLACE INTO architectural_features VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), prediction_id, "__vision_meta__",
                        json.dumps({"status": result["feature_detection_status"], "note": result.get("parts_note", "")}), None, now))
    return prediction_id


@app.post("/api/analysis/predict", status_code=201)
async def predict(image: Annotated[UploadFile, File()], user: Annotated[dict, Depends(bearer_user)]):
    data, decoded = await read_image(image)
    result = await run_in_threadpool(analyze_image, decoded)
    image_format = Image.open(io.BytesIO(data)).format or "JPEG"
    mime_type = {"PNG": "image/png", "WEBP": "image/webp"}.get(image_format, "image/jpeg")
    prediction_id = save_prediction(user["id"], image.filename or "upload", data, result, mime_type)
    return {"id": prediction_id, "filename": Path(image.filename or "upload").name, **result}


def compare_visuals(reference: Image.Image, comparison: Image.Image) -> dict:
    """Compare image-level shape, edge layout and color without claiming semantic detection."""
    size = (256, 256)
    ref_rgb = reference.convert("RGB").resize(size)
    cmp_rgb = comparison.convert("RGB").resize(size)
    ref_gray = ImageOps.autocontrast(ref_rgb.convert("L"))
    cmp_gray = ImageOps.autocontrast(cmp_rgb.convert("L"))

    def mean_absolute_difference(left: Image.Image, right: Image.Image) -> float:
        diff = ImageChops.difference(left, right)
        histogram = diff.histogram()
        return sum(index * count for index, count in enumerate(histogram)) / (size[0] * size[1] * 255)

    def edge_profile(edge_map: Image.Image, horizontal: bool) -> list[float]:
        pixels = edge_map.load()
        length = size[1] if horizontal else size[0]
        across = size[0] if horizontal else size[1]
        return [sum(pixels[x, i] if horizontal else pixels[i, x] for x in range(across)) / (across * 255) for i in range(length)]

    def cosine_similarity(left: list[float], right: list[float]) -> float:
        dot = sum(a * b for a, b in zip(left, right))
        magnitude = (sum(a * a for a in left) * sum(b * b for b in right)) ** 0.5
        if magnitude == 0:
            return 1.0 if not any(left) and not any(right) else 0.0
        return max(0.0, min(1.0, dot / magnitude))

    ref_edges = ref_gray.filter(ImageFilter.FIND_EDGES).point(lambda value: 255 if value >= 48 else 0)
    cmp_edges = cmp_gray.filter(ImageFilter.FIND_EDGES).point(lambda value: 255 if value >= 48 else 0)
    pixel_similarity = max(0.0, 1.0 - mean_absolute_difference(ref_gray, cmp_gray))
    edge_similarity = max(0.0, 1.0 - mean_absolute_difference(ref_edges, cmp_edges))
    horizontal_similarity = cosine_similarity(edge_profile(ref_edges, True), edge_profile(cmp_edges, True))
    vertical_similarity = cosine_similarity(edge_profile(ref_edges, False), edge_profile(cmp_edges, False))
    ref_hist = ref_rgb.histogram()
    cmp_hist = cmp_rgb.histogram()
    color_similarity = sum(min(a, b) for a, b in zip(ref_hist, cmp_hist)) / (3 * size[0] * size[1])
    ref_density = sum(ref_edges.histogram()[1:]) / (size[0] * size[1])
    cmp_density = sum(cmp_edges.histogram()[1:]) / (size[0] * size[1])
    structure_similarity = 0.5 * edge_similarity + 0.25 * horizontal_similarity + 0.25 * vertical_similarity
    metrics = {
        "pixel_similarity": round(pixel_similarity, 4),
        "structure_similarity": round(structure_similarity, 4),
        "edge_similarity": round(edge_similarity, 4),
        "horizontal_layer_pattern_similarity": round(horizontal_similarity, 4),
        "vertical_shape_pattern_similarity": round(vertical_similarity, 4),
        "color_similarity": round(color_similarity, 4),
        "reference_edge_density": round(ref_density, 4),
        "comparison_edge_density": round(cmp_density, 4),
    }
    observations = []
    if structure_similarity < 0.75:
        observations.append("The overall edge and shape layout differs noticeably.")
    else:
        observations.append("The broad edge and shape layout is similar.")
    if horizontal_similarity < 0.75:
        observations.append("Horizontal band or tier patterns differ.")
    if vertical_similarity < 0.75:
        observations.append("Vertical shape patterns differ.")
    if color_similarity < 0.75:
        observations.append("Color and surface appearance differ.")
    if abs(ref_density - cmp_density) >= 0.08:
        observations.append("The amount of edge detail differs; this can reflect surface texture or image quality.")
    analysis = " ".join(observations) + " These are image-level measurements; the system does not identify named objects such as pillars or gopurams."
    return {"similarity": pixel_similarity, "metrics": metrics, "observations": observations, "analysis": analysis,
            "method": "normalized grayscale, edge-map, band-profile and color-histogram comparison"}


@app.post("/api/analysis/compare")
async def compare(reference: Annotated[UploadFile, File()], comparison: Annotated[UploadFile, File()], user: Annotated[dict, Depends(bearer_user)]):
    ref_data, ref_image = await read_image(reference)
    cmp_data, cmp_image = await read_image(comparison)
    ref_format = Image.open(io.BytesIO(ref_data)).format
    cmp_format = Image.open(io.BytesIO(cmp_data)).format
    result = await run_in_threadpool(compare_visuals, ref_image, cmp_image)
    similarity = result["similarity"]
    analysis = result["analysis"]
    now = datetime.now(timezone.utc).isoformat()
    comparison_id = str(uuid.uuid4())
    with connection() as db:
        image_ids = []
        for upload, data, image_format in ((reference, ref_data, ref_format), (comparison, cmp_data, cmp_format)):
            image_id = str(uuid.uuid4())
            safe_name = Path(upload.filename or "upload").name[:120]
            mime_type = {"PNG": "image/png", "WEBP": "image/webp"}.get(image_format, "image/jpeg")
            path = (UPLOAD_DIR / f"{image_id}_{safe_name}").resolve()
            path.write_bytes(data)
            db.execute("INSERT INTO uploaded_images VALUES(?,?,?,?,?,?,?,?)",
                       (image_id, user["id"], None, safe_name, str(path), mime_type, len(data), now))
            image_ids.append(image_id)
        db.execute("INSERT INTO comparisons(id,user_id,reference_image_id,comparison_image_id,similarity,analysis,created_at,metrics_json) VALUES(?,?,?,?,?,?,?,?)",
                   (comparison_id, user["id"], image_ids[0], image_ids[1], similarity, analysis, now, json.dumps(result)))
    return {"id": comparison_id, "similarity": round(similarity, 4), "similarity_percent": round(similarity * 100, 2),
            "method": result["method"], "analysis": analysis, "metrics": result["metrics"], "observations": result["observations"], "created_at": now}


@app.post("/api/analysis/compare/{prediction_id}")
async def compare_with_saved_image(prediction_id: str, comparison: Annotated[UploadFile, File()], user: Annotated[dict, Depends(bearer_user)]):
    record = prediction_or_404(prediction_id, user["id"])
    ref_path = stored_path(record["storage_path"])
    if not ref_path.is_file():
        raise HTTPException(status_code=404, detail="Saved reference image is missing")
    try:
        with Image.open(ref_path) as ref_source:
            ref_image = ImageOps.exif_transpose(ref_source).convert("RGB")
    except (OSError, UnidentifiedImageError):
        raise HTTPException(status_code=415, detail="Saved reference image cannot be decoded")
    cmp_data, cmp_image = await read_image(comparison)
    result = await run_in_threadpool(compare_visuals, ref_image, cmp_image)
    similarity = result["similarity"]
    analysis = result["analysis"]
    now = datetime.now(timezone.utc).isoformat()
    comparison_id = str(uuid.uuid4())
    image_id = str(uuid.uuid4())
    safe_name = Path(comparison.filename or "comparison").name[:120]
    with Image.open(io.BytesIO(cmp_data)) as source:
        mime_type = Image.MIME[source.format]
    path = (UPLOAD_DIR / f"{image_id}_{safe_name}").resolve()
    path.write_bytes(cmp_data)
    with connection() as db:
        db.execute("INSERT INTO uploaded_images VALUES(?,?,?,?,?,?,?,?)",
                   (image_id, user["id"], None, safe_name, str(path), mime_type, len(cmp_data), now))
        db.execute("INSERT INTO comparisons(id,user_id,reference_image_id,comparison_image_id,similarity,analysis,created_at,metrics_json) VALUES(?,?,?,?,?,?,?,?)",
                   (comparison_id, user["id"], record["uploaded_image_id"], image_id, similarity, analysis, now, json.dumps(result)))
    return {"id": comparison_id, "similarity": round(similarity, 4), "similarity_percent": round(similarity * 100, 2),
            "reference_name": record["filename"], "comparison_name": safe_name,
            "method": result["method"], "analysis": analysis, "metrics": result["metrics"], "observations": result["observations"], "created_at": now}


@app.get("/api/temples")
def search_temples(q: str = "", style: str = ""):
    if len(q) > 120 or len(style) > 20:
        raise HTTPException(status_code=422, detail="Search terms are too long")
    query = f"%{q.strip()}%"
    parameters: list[object] = [query, query, query]
    style_clause = ""
    if style:
        style_clause = " AND architecture=?"
        parameters.append(style.strip().upper())
    with connection() as db:
        rows = db.execute("""SELECT id,name,architecture,location,description,details_json
            FROM temples WHERE (name LIKE ? OR location LIKE ? OR description LIKE ?)""" + style_clause + " ORDER BY name",
            parameters).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["details"] = json.loads(item.pop("details_json") or "{}")
        items.append(item)
    return {"items": items, "query": q, "count": len(items)}


def prediction_or_404(prediction_id: str, user_id: str):
    with connection() as db:
        row = db.execute("SELECT p.id,i.id AS uploaded_image_id,i.original_filename AS filename,i.storage_path,i.mime_type,p.architecture,p.confidence,p.analysis,p.model_version,p.created_at FROM predictions p JOIN uploaded_images i ON i.id=p.uploaded_image_id WHERE p.id=? AND p.user_id=?",
                         (prediction_id, user_id)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return dict(row)


def unpack_architectural_features(rows) -> tuple[dict, list[dict], str, str]:
    """Read legacy text features and newer JSON-serialized AI part boxes."""
    features, parts = {}, []
    status, note = "not_configured", ""
    for row in rows:
        name, value = row["feature_name"], row["feature_value"]
        if name == "__vision_meta__":
            try:
                metadata = json.loads(value)
                status, note = metadata.get("status", status), metadata.get("note", note)
            except (TypeError, json.JSONDecodeError):
                pass
            continue
        try:
            parsed = json.loads(value)
        except (TypeError, json.JSONDecodeError):
            parsed = None
        if isinstance(parsed, dict) and isinstance(parsed.get("bbox"), list) and len(parsed["bbox"]) == 4:
            parts.append({"name": name, "bbox": parsed["bbox"], "evidence": parsed.get("evidence", "")})
        else:
            features[name] = value
    return features, parts, status, note


@app.get("/api/history")
def history(user: Annotated[dict, Depends(bearer_user)], limit: int = 50, offset: int = 0):
    if not 1 <= limit <= 100 or offset < 0:
        raise HTTPException(status_code=422, detail="limit must be 1..100 and offset must be non-negative")
    with connection() as db:
        rows = db.execute("SELECT p.id,i.original_filename AS filename,p.architecture,p.confidence,p.analysis,p.created_at FROM prediction_history h JOIN predictions p ON p.id=h.prediction_id JOIN uploaded_images i ON i.id=p.uploaded_image_id WHERE h.user_id=? ORDER BY h.created_at DESC LIMIT ? OFFSET ?",
                          (user["id"], limit, offset)).fetchall()
        items = [dict(row) for row in rows]
        for item in items:
            features = db.execute("SELECT feature_name,feature_value,confidence FROM architectural_features WHERE prediction_id=?", (item["id"],)).fetchall()
            item["features"], item["parts"], item["feature_detection_status"], item["parts_note"] = unpack_architectural_features(features)
    return {"items": items, "limit": limit, "offset": offset}


@app.get("/api/comparisons")
def list_comparisons(user: Annotated[dict, Depends(bearer_user)], limit: int = 50, offset: int = 0):
    if not 1 <= limit <= 100 or offset < 0:
        raise HTTPException(status_code=422, detail="limit must be 1..100 and offset must be non-negative")
    with connection() as db:
        rows = db.execute("""
            SELECT c.id,c.similarity,c.analysis,c.created_at,c.metrics_json,
                   ri.original_filename AS reference_name,ci.original_filename AS comparison_name
            FROM comparisons c
            JOIN uploaded_images ri ON ri.id=c.reference_image_id
            JOIN uploaded_images ci ON ci.id=c.comparison_image_id
            WHERE c.user_id=? ORDER BY c.created_at DESC LIMIT ? OFFSET ?
        """, (user["id"], limit, offset)).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        try:
            stored_metrics = json.loads(item.pop("metrics_json") or "{}")
        except json.JSONDecodeError:
            stored_metrics = {}
        item.update({key: value for key, value in stored_metrics.items() if key != "analysis"})
        items.append(item)
    return {"items": items, "limit": limit, "offset": offset}


@app.get("/api/history/{prediction_id}")
def get_analysis(prediction_id: str, user: Annotated[dict, Depends(bearer_user)]):
    record = prediction_or_404(prediction_id, user["id"])
    image_path = stored_path(record["storage_path"])
    record["image_url"] = f"/history/{prediction_id}/image" if image_path.is_file() else None
    with connection() as db:
        features = db.execute("SELECT feature_name,feature_value,confidence FROM architectural_features WHERE prediction_id=?", (prediction_id,)).fetchall()
    record["features"], record["parts"], record["feature_detection_status"], record["parts_note"] = unpack_architectural_features(features)
    if image_path.is_file():
        try:
            with Image.open(image_path) as stored_image:
                upright = ImageOps.exif_transpose(stored_image)
                record["image_dimensions"] = {"width": upright.width, "height": upright.height}
        except (OSError, UnidentifiedImageError):
            record["image_dimensions"] = None
    return record


@app.get("/api/history/{prediction_id}/image")
def get_analysis_image(prediction_id: str, user: Annotated[dict, Depends(bearer_user)]):
    record = prediction_or_404(prediction_id, user["id"])
    image_path = stored_path(record["storage_path"])
    if not image_path.is_file():
        raise HTTPException(status_code=404, detail="Stored image is missing")
    return FileResponse(image_path, media_type=record["mime_type"])


@app.post("/api/history/{prediction_id}/parts")
async def retry_part_mapping(prediction_id: str, user: Annotated[dict, Depends(bearer_user)]):
    record = prediction_or_404(prediction_id, user["id"])
    try:
        with Image.open(stored_path(record["storage_path"])) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
    except (OSError, UnidentifiedImageError):
        raise HTTPException(status_code=404, detail="Saved image is missing or unreadable")
    parts, status, note = await run_in_threadpool(detect_parts, image, record["architecture"])
    if status in {"unavailable", "not_configured"}:
        raise HTTPException(status_code=503, detail=note or "AI mapping is not configured")
    now = datetime.now(timezone.utc).isoformat()
    with connection() as db:
        db.execute("DELETE FROM architectural_features WHERE prediction_id=?", (prediction_id,))
        counts = {}
        for part in parts:
            counts[part["name"]] = counts.get(part["name"], 0) + 1
            name = part["name"] if counts[part["name"]] == 1 else f"{part['name']} {counts[part['name']]}"
            db.execute("INSERT INTO architectural_features VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), prediction_id, name,
                        json.dumps({"bbox": part["bbox"], "evidence": part.get("evidence", "")}), None, now))
        db.execute("INSERT INTO architectural_features VALUES(?,?,?,?,?,?)",
                   (str(uuid.uuid4()), prediction_id, "__vision_meta__",
                    json.dumps({"status": status, "note": note}), None, now))
    return get_analysis(prediction_id, user)


@app.post("/api/reports/{prediction_id}", status_code=201)
def generate_report(prediction_id: str, user: Annotated[dict, Depends(bearer_user)]):
    record = prediction_or_404(prediction_id, user["id"])
    with connection() as db:
        feature_rows = db.execute("SELECT feature_name,feature_value FROM architectural_features WHERE prediction_id=? AND feature_name != '__vision_meta__'", (prediction_id,)).fetchall()
        comparison_rows = db.execute("""SELECT c.analysis,c.similarity,c.metrics_json,c.created_at,
            ri.original_filename AS reference_name,ci.original_filename AS comparison_name
            FROM comparisons c JOIN uploaded_images ri ON ri.id=c.reference_image_id
            JOIN uploaded_images ci ON ci.id=c.comparison_image_id
            WHERE c.user_id=? AND c.reference_image_id=? ORDER BY c.created_at DESC LIMIT 20""",
            (user["id"], record["uploaded_image_id"])).fetchall()
    path = REPORT_DIR / f"{prediction_id}.pdf"
    pdf = canvas.Canvas(str(path), pagesize=letter)
    pdf.setTitle(f"Architecture analysis {prediction_id}")
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawString(72, 740, "Architecture Analysis Report")
    pdf.setFont("Helvetica", 11)
    lines = [f"Analysis ID: {record['id']}", f"Image: {record['filename']}",
             f"Architecture: {record['architecture']}", f"Confidence: {record['confidence']:.2%}",
             f"Created: {record['created_at']}", "", "Analysis:", record["analysis"]]
    if feature_rows:
        lines.extend(["", "AI-located architectural parts (boxes use 0-1000 normalized image coordinates):"])
        for row in feature_rows:
            try:
                detail = json.loads(row["feature_value"])
            except (TypeError, json.JSONDecodeError):
                detail = None
            if isinstance(detail, dict) and isinstance(detail.get("bbox"), list):
                lines.append(f"- {row['feature_name']}: box {detail['bbox']}")
                if detail.get("evidence"):
                    lines.append(f"  Visual cue: {detail['evidence']}")
            else:
                lines.append(f"- {row['feature_name']}: {row['feature_value']}")
    else:
        lines.extend(["", "AI-located parts: No visible part boxes were saved for this prediction."])
    if comparison_rows:
        lines.extend(["", "Comparison results:"])
        for row in comparison_rows:
            try:
                comparison_data = json.loads(row["metrics_json"] or "{}")
                metrics = comparison_data.get("metrics", {})
            except (json.JSONDecodeError, TypeError):
                metrics = {}
            structure = metrics.get("structure_similarity")
            color = metrics.get("color_similarity")
            scores = f", shape/edge similarity {structure:.1%}" if isinstance(structure, (int, float)) else ""
            scores += f", color similarity {color:.1%}" if isinstance(color, (int, float)) else ""
            lines.append(f"- {row['reference_name']} vs {row['comparison_name']}: {row['similarity']:.1%} pixel similarity{scores}")
            lines.append(f"  {row['analysis']}")
    else:
        lines.extend(["", "Comparison results: No saved comparisons for this reference image."])
    image_path = stored_path(record["storage_path"])
    if image_path.is_file():
        try:
            with Image.open(image_path) as source:
                upright = ImageOps.exif_transpose(source).convert("RGB")
                pdf.drawImage(ImageReader(upright), 72, 470, width=230, height=190,
                              preserveAspectRatio=True, anchor="c", mask="auto")
        except (OSError, ValueError):
            pass
    y = 440
    for paragraph in lines:
        safe_paragraph = unicodedata.normalize("NFKC", str(paragraph)).encode("cp1252", "replace").decode("cp1252")
        wrapped_lines = textwrap.wrap(safe_paragraph, width=95, break_long_words=True) or [""]
        for line in wrapped_lines:
            if y < 55:
                pdf.showPage()
                pdf.setFont("Helvetica", 11)
                y = 740
            pdf.drawString(72, y, line)
            y -= 16
    pdf.save()
    return {"id": prediction_id, "download_url": f"/api/reports/{prediction_id}/download"}


@app.get("/api/reports/{prediction_id}/download")
def download_report(prediction_id: str, user: Annotated[dict, Depends(bearer_user)]):
    prediction_or_404(prediction_id, user["id"])
    path = REPORT_DIR / f"{prediction_id}.pdf"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Report has not been generated")
    return FileResponse(path, media_type="application/pdf", filename=f"architecture-analysis-{prediction_id}.pdf")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/")
def root():
    return {
        "name": app.title,
        "status": "ok",
        "docs": "/docs",
        "health": "/api/health",
        "api_prefix": "/api",
        "frontend": "http://localhost:5173",
    }
