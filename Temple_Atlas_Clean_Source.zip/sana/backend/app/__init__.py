"""Architecture analysis API."""

from pathlib import Path

from dotenv import load_dotenv

# Load configuration before main/model read settings; shell values take precedence.
load_dotenv(Path(__file__).resolve().parents[1] / ".env")
