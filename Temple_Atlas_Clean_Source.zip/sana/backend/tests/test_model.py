"""Check that simultaneous first requests share one model initialization."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from app import model


class ModelTests(unittest.TestCase):
    def test_concurrent_initialization_trains_once(self):
        artifact = {'version': 'test'}

        def train_once():
            time.sleep(.05)
            with model._lock:
                model._cached_model = artifact

        with tempfile.TemporaryDirectory() as directory:
            with patch.object(model, '_cached_model', None), patch.object(model, 'MODEL_PATH', Path(directory) / 'missing.npz'), patch.object(model, 'train_model', side_effect=train_once) as train:
                with ThreadPoolExecutor(max_workers=4) as executor:
                    results = list(executor.map(lambda _: model._load_model(), range(4)))
                self.assertEqual(train.call_count, 1)
                self.assertTrue(all(result is artifact for result in results))
