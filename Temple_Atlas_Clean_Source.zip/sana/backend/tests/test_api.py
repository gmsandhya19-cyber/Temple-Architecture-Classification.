"""Local integration checks using isolated storage and no external AI calls."""
import io
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ["ENABLE_AI_PART_DETECTION"] = "false"

from fastapi.testclient import TestClient
from PIL import Image, ImageDraw
from app import main
from fastapi import HTTPException


class ApiTests(unittest.TestCase):
    def test_large_image_rejected_before_decode(self):
        with patch.object(main.Image, 'open') as open_image:
            header = open_image.return_value.__enter__.return_value
            header.format = 'PNG'
            header.width, header.height = 8000, 8000
            with self.assertRaises(HTTPException) as rejected:
                main.decode_image(b'header-only')
            self.assertEqual(rejected.exception.status_code, 413)
            header.verify.assert_not_called()
            self.assertEqual(open_image.call_count, 1)

    def test_report_uses_upright_image(self):
        image = Image.new('RGB', (80, 120), 'white')
        exif = Image.Exif()
        exif[274] = 6
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.multiple(main, DATABASE_PATH=root / 'test.db',
                                UPLOAD_DIR=root / 'uploads', REPORT_DIR=root / 'reports'), TestClient(main.app) as client:
                response = client.post('/api/auth/register', json={'email': 'report@example.com', 'password': 'test-password-123'})
                client.headers['Authorization'] = 'Bearer ' + response.json()['access_token']
                buffer = io.BytesIO()
                image.save(buffer, format='JPEG', exif=exif)
                with patch.object(main, 'analyze_image', return_value={'architecture': 'NAGARA', 'confidence': .4, 'analysis': 'Test'}):
                    prediction = client.post('/api/analysis/predict', files={'image': ('rotated.jpg', buffer.getvalue(), 'image/jpeg')})
                self.assertEqual(prediction.status_code, 201, prediction.text)
                with patch.object(main, 'ImageReader', wraps=main.ImageReader) as reader:
                    report = client.post('/api/reports/' + prediction.json()['id'])
                self.assertEqual(report.status_code, 201, report.text)
                self.assertEqual(reader.call_args.args[0].size, (120, 80))

    def test_prediction_includes_part_mapping(self):
        result = {'architecture': 'DRAVIDA', 'confidence': 0.5, 'analysis': 'Local result'}
        with patch.dict(os.environ, {'ENABLE_AI_PART_DETECTION': 'true', 'GEMINI_API_KEY': 'test-only'}), patch.object(main, 'predict_image', return_value=result), patch.object(main, 'detect_parts', return_value=([{'name': 'Mandapa', 'bbox': [10, 20, 200, 300]}], 'available', 'Visible hall')) as vision:
            prediction = main.analyze_image(Image.new('RGB', (80, 80)))
        vision.assert_called_once()
        self.assertEqual(prediction['feature_detection_status'], 'available')
        self.assertEqual(prediction['parts'][0]['name'], 'Mandapa')
        self.assertEqual(prediction['confidence'], 0.5)

    def test_each_login_has_a_unique_token(self):
        self.assertNotEqual(main.make_token("same-user"), main.make_token("same-user"))

    def test_account_analysis_comparison_and_report(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.multiple(main, DATABASE_PATH=root / "test.db",
                                UPLOAD_DIR=root / "uploads", REPORT_DIR=root / "reports"), TestClient(main.app) as client:
                self.assertEqual(client.get("/api/health").status_code, 200)
                self.assertEqual(client.get("/api/history").status_code, 401)
                credentials = {"email": "test@example.com", "password": "test-password-123"}
                registration = client.post("/api/auth/register", json=credentials)
                self.assertEqual(registration.status_code, 201, registration.text)
                client.headers["Authorization"] = "Bearer " + registration.json()["access_token"]
                self.assertEqual(client.get("/api/profile").status_code, 200)
                image = Image.new("RGB", (80, 120), "white")
                ImageDraw.Draw(image).rectangle((10, 30, 45, 100), fill="red")
                buffer = io.BytesIO()
                exif = Image.Exif()
                exif[274] = 6
                image.save(buffer, format="PNG", exif=exif)
                upload = ("temple.png", buffer.getvalue(), "image/png")
                prediction = client.post("/api/analysis/predict", files={"image": upload})
                self.assertEqual(prediction.status_code, 201, prediction.text)
                prediction_id = prediction.json()["id"]
                self.assertEqual(prediction.json()["image_dimensions"], {"width": 120, "height": 80})
                comparison = client.post(f"/api/analysis/compare/{prediction_id}", files={"comparison": upload})
                self.assertEqual(comparison.status_code, 200, comparison.text)
                self.assertEqual(comparison.json()["similarity"], 1.0)
                with main.connection() as db:
                    types = [row[0] for row in db.execute("SELECT mime_type FROM uploaded_images")]
                self.assertEqual(types, ["image/png", "image/png"])
                with patch.object(main, 'detect_parts', return_value=([{'name':'Mandapa','bbox':[10,20,200,300],'evidence':'Visible hall'}], 'available', '')):
                    mapped = client.post(f"/api/history/{prediction_id}/parts")
                self.assertEqual(mapped.status_code, 200, mapped.text)
                self.assertEqual(mapped.json()['parts'][0]['name'], 'Mandapa')
                with patch.object(main, 'detect_parts', return_value=([], 'unavailable', 'Temporary failure')):
                    self.assertEqual(client.post(f"/api/history/{prediction_id}/parts").status_code, 503)
                self.assertEqual(client.get(f"/api/history/{prediction_id}").json()['parts'][0]['name'], 'Mandapa')
                self.assertEqual(client.get("/api/history").json()["items"][0]["id"], prediction_id)
                self.assertEqual(client.get(f"/api/history/{prediction_id}/image").status_code, 200)
                self.assertEqual(client.post(f"/api/reports/{prediction_id}").status_code, 201)
                self.assertTrue(client.get(f"/api/reports/{prediction_id}/download").content.startswith(b"%PDF"))
                invalid = client.post("/api/analysis/predict", files={"image": ("bad.jpg", b"invalid", "image/jpeg")})
                self.assertEqual(invalid.status_code, 415)
                other = client.post("/api/auth/register", json={**credentials, "email": "other@example.com"})
                self.assertEqual(client.get(f"/api/history/{prediction_id}", headers={"Authorization": "Bearer " + other.json()["access_token"]}).status_code, 404)
                self.assertEqual(client.post("/api/auth/logout").status_code, 200)
                self.assertEqual(client.get("/api/profile").status_code, 401)
                login = client.post("/api/auth/login", json=credentials)
                self.assertEqual(login.status_code, 200)
                client.headers["Authorization"] = "Bearer " + login.json()["access_token"]
                self.assertEqual(client.get("/api/profile").status_code, 200)

    def test_vertical_and_horizontal_profiles_are_distinct(self):
        first = Image.new("RGB", (256, 256), "white")
        second = first.copy()
        ImageDraw.Draw(first).rectangle((30, 40, 60, 180), fill="black")
        ImageDraw.Draw(second).rectangle((170, 40, 200, 180), fill="black")
        metrics = main.compare_visuals(first, second)["metrics"]
        self.assertEqual(metrics["horizontal_layer_pattern_similarity"], 1.0)
        self.assertLess(metrics["vertical_shape_pattern_similarity"], 0.9)


if __name__ == "__main__":
    unittest.main()
