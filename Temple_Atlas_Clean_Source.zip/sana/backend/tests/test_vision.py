﻿import io
import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from PIL import Image
from app import vision

class VisionTests(unittest.TestCase):
    @patch.dict('os.environ', {'ENABLE_AI_PART_DETECTION':'true','GEMINI_API_KEY':'test-only'})
    def test_malformed_content_does_not_crash(self):
        for content in [None, [], {'parts': None}, {'parts': [{'text': None}]}]:
            response = io.BytesIO(json.dumps({'candidates': [{'content': content}]}).encode())
            with self.subTest(content=content), patch.object(vision, 'urlopen', return_value=response):
                parts, status, _ = vision.detect_parts(Image.new('RGB', (64,64)), 'DRAVIDA')
            self.assertEqual(parts, [])
            self.assertEqual(status, 'unavailable')

    def response(self):
        return io.BytesIO(json.dumps({'candidates':[{'content':{'parts':[{'text':json.dumps({'parts':[{'name':'Mandapa','x1':10,'y1':20,'x2':300,'y2':400,'evidence':'Visible hall'}],'note':''})}]}}]}).encode())

    @patch.dict('os.environ', {'ENABLE_AI_PART_DETECTION':'true','GEMINI_API_KEY':'test-only','GEMINI_VISION_MODEL':'primary','GEMINI_VISION_FALLBACK_MODELS':'fallback'})
    def test_transient_error_uses_fallback(self):
        failures=[HTTPError('https://test',503,'Unavailable',{},None) for _ in range(1)]
        with patch.object(vision,'urlopen',side_effect=failures+[self.response()]) as send:
            parts,status,_=vision.detect_parts(Image.new('RGB',(64,64)),'DRAVIDA')
        self.assertEqual(status,'available')
        self.assertEqual(len(parts),1)
        self.assertEqual(send.call_count,2)
        self.assertLessEqual(send.call_args.kwargs['timeout'],20)
        self.assertIn('/fallback:',send.call_args.args[0].full_url)

    @patch.dict('os.environ', {'ENABLE_AI_PART_DETECTION':'true','GEMINI_API_KEY':'test-only'})
    def test_rejected_key_is_not_retried(self):
        with patch.object(vision,'urlopen',side_effect=HTTPError('https://test',403,'Denied',{},None)) as send:
            _,status,note=vision.detect_parts(Image.new('RGB',(64,64)),'DRAVIDA')
        self.assertEqual(status,'unavailable')
        self.assertEqual(send.call_count,1)
        self.assertIn('permissions',note)
