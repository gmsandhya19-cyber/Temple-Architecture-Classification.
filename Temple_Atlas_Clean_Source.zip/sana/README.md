# Temple Atlas — setup and run

Run these commands in PowerShell. Keep the backend and frontend running in **two separate terminals**.

Project folder:

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project"
```

## 1. Backend: first-time setup

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\backend"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (!(Test-Path .env)) { Copy-Item .env.example .env }
```

Edit `backend/.env` for local configuration. The backend loads it automatically. Existing shell environment variables take precedence. Keep your actual API key in `.env`; do not put it in `.env.example` or commit it.

For optional AI part mapping, configure:

```dotenv
ENABLE_AI_PART_DETECTION=true
GEMINI_API_KEY=your_actual_key
GEMINI_VISION_MODEL=gemini-3.5-flash
GEMINI_VISION_FALLBACK_MODELS=gemini-3.1-flash-lite
```

Mapping sends analyzed photos to Google Gemini and may incur API charges. Set `ENABLE_AI_PART_DETECTION=false` to run the local classifier without Gemini. Provider availability and visible architectural detail determine whether boxes can be returned.

Keep the existing `JWT_SECRET` unchanged. For a fresh setup only, generate a secret using this command and paste its output into `JWT_SECRET` in `.env`:

```powershell
.\.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(48))"
```

Changing the secret invalidates existing sessions and requires signing in again.

## 2. Terminal 1: run the backend

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\backend"
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

These commands call the virtual environment's Python directly, so PowerShell activation is unnecessary.

Backend: <http://127.0.0.1:8000>

API documentation: <http://127.0.0.1:8000/docs>

The background server used during troubleshooting ran the same command without `--reload`:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Use only one backend server at a time.

## 3. Frontend: first-time setup

In a second PowerShell terminal:

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\frontend"
npm.cmd ci
if (!(Test-Path .env)) { Copy-Item .env.example .env }
```

The frontend `.env` should contain:

```dotenv
VITE_API_URL=/api
```

Vite proxies `/api` requests to `http://127.0.0.1:8000`.

## 4. Terminal 2: run the frontend

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\frontend"
npm.cmd run dev
```

Open **<http://localhost:5173>**.

In this project, `dev` builds the app and serves the compiled files with Vite preview. It does not provide hot reload. After source changes, stop it with `Ctrl+C`, run `npm.cmd run dev` again, and refresh the browser with `Ctrl+F5`.

Alternatively, build and serve separately:

```powershell
npm.cmd run build
npm.cmd run preview
```

Use only one frontend server at a time. `npm.cmd` avoids PowerShell restrictions on the `npm.ps1` script.

## Verification commands used

Backend tests and dependency check:

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\backend"
.\.venv\Scripts\python.exe -m pip install -r dev-requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m pip check
```

Frontend build check:

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\frontend"
npm.cmd run build
```

With both servers running, check the backend directly and through the frontend proxy:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/health
Invoke-RestMethod http://localhost:5173/api/health
```

Both should return `status: ok`.

## Optional: retrain the local classifier

The included model can be used without retraining. To retrain using `dataset/training`:

```powershell
cd "C:\Users\BOSSP\OneDrive\Desktop\project\backend"
.\.venv\Scripts\python.exe train_model.py
```

This replaces the trained model artifact. Restart the backend afterward to load the updated model.

## Restart and troubleshooting

- Stop each server with `Ctrl+C` in its terminal, then run its start command again. Restart the backend after editing `backend/.env`.
- If port 8000 or 5173 is already occupied, stop the existing project server before starting another. To inspect listeners:

  ```powershell
  netstat -ano | Select-String ':8000.*LISTENING|:5173.*LISTENING'
  ```

- For `Invalid or expired token`, refresh with `Ctrl+F5` and sign in again.
- For API connection errors, run both health checks above and confirm `frontend/.env` uses `/api`.
- For temporary AI mapping errors, open the saved analysis and click **Retry AI mapping**. The backend automatically retries temporary failures and attempts its fallback model.

More details: [backend README](backend/README.md) and [frontend README](frontend/README.md).

### Prediction and mapping together

Uploads wait for both the local architecture prediction and enabled Gemini part mapping before displaying the result. The primary and fallback models each get one attempt with a 20-second socket timeout, instead of repeated minute-long attempts. If Gemini remains unavailable, the result shows the prediction and a mapping error; use **Retry AI mapping** on the saved photo. Disable `ENABLE_AI_PART_DETECTION` for faster local-only predictions.
