# Temple Atlas

General Project Documentation

29 October 2026

## Project overview

Temple Atlas is a web application for exploring Indian temple architecture through photographs. It brings image classification, visual comparison, a temple reference directory, saved analysis history, and downloadable reports into one personal workspace. The application is suitable as an educational and demonstration project; its predictions require review against architectural and historical evidence.

## Problem and purpose

Temple photographs can be difficult to organize and compare, especially for learners who are unfamiliar with architectural styles. Temple Atlas provides a consistent process for uploading a photograph, receiving a broad style prediction, reviewing the result, and keeping a record for later study.

The project focuses on three architecture categories: Nagara, Dravida, and Vesara. It predicts a broad category rather than identifying the exact temple, its date, or its historical authenticity.

## Objectives

- Provide an accessible interface for studying temple photographs.

- Predict broad architectural style using a local image classifier.

- Optionally locate visible architectural parts through Gemini image analysis.

- Support image comparison, personal history, and PDF documentation.

## Intended users

Potential users include students, teachers, architecture enthusiasts, and researchers organizing preliminary visual studies. Architectural interpretation remains the responsibility of the user.

## Features and user workflow

### Accounts and personal workspace

Users can register, sign in, update their email address, and change their password. Analyses and comparisons are associated with the signed-in account. Signed-out visitors can view clearly marked sample dashboard information and browse the temple directory.

### Image analysis

Users upload JPEG, PNG, or WebP images. The backend validates the image, corrects its orientation, and predicts an architectural category. The result includes model confidence, an explanation, and saved image details. Optional Gemini processing can add bounding boxes around visible architectural parts.

### Comparison and reference information

Two uploaded images can be compared, or a new image can be compared with an existing saved analysis. Measurements describe pixel similarity, edge and shape patterns, and color. They do not establish that two temples have the same historical style or detect a missing named component. The searchable temple directory provides reference descriptions and source links.

### History and reports

Saved analyses can be reopened to inspect the image and results. When configured, users can retry AI part mapping on a saved photograph. PDF reports include the uploaded image, classification, confidence, analysis notes, saved part information, and associated comparisons where available.

### Typical workflow

- Create an account or sign in to the application.

- Upload a supported photograph of a temple.

- Review the predicted style and its model confidence.

- Review any optional AI part boxes and verify their interpretation.

- Compare the image with another photograph when useful.

- Revisit the saved result through history or generate a PDF report.

If optional AI mapping fails, the local prediction can still be returned with a mapping status message. A retry can be requested from the saved analysis.

## Architecture and implementation

### System structure

The React frontend sends HTTP requests to a FastAPI backend. The backend manages authentication, image processing, data access, and report generation. SQLite stores structured records, while uploaded images and generated reports are stored as files. When enabled, the backend sends images to Google Gemini for part mapping.

### Technology stack

- Interface: React, Vite, Lucide icons, and Recharts.

- API and validation: Python, FastAPI, and Pydantic.

- Storage: SQLite database and local filesystem.

- Image processing and classification: Pillow, NumPy, and scikit-image.

- Authentication: bcrypt password hashing and signed JWT access tokens.

- Reports and optional vision: ReportLab and the Gemini API.

### Classification method

The local pipeline corrects EXIF orientation, converts the photograph to RGB, resizes it to 160 by 160 pixels, applies median filtering and contrast enhancement, and extracts HOG shape descriptors with RGB and HSV color histograms. A cosine-neighbour voting method compares these features with stored training examples to select a class.

The supplied training folders contain 150 images, with 50 files in each category. The README reports approximately 43.3 percent accuracy from stratified five-fold cross-validation. This evaluation was not rerun during the project review. The returned confidence is a model score and has not been shown to be a calibrated probability of correctness.

### Data and access control

The database stores users, temples, uploaded images, predictions, architectural features, comparisons, prediction history, and revoked tokens. Protected routes check account ownership. Logout revokes the current token; changing a password invalidates existing sessions. The frontend stores its access token in session storage.

## Operation and current status

### Local setup

Install Python and Node.js, then open two terminals from the project root. Create a backend virtual environment and install backend/requirements.txt. Copy backend/.env.example to backend/.env and configure a stable JWT_SECRET. The backend loads this file automatically; existing shell variables take precedence.

Start the API from the backend directory with the virtual environment Python and the command: python -m uvicorn app.main:app --host 127.0.0.1 --port 8000. Interactive API documentation is available at http://127.0.0.1:8000/docs.

In the frontend directory, run npm.cmd ci, configure VITE_API_URL=/api in the frontend environment file, and run npm.cmd run dev. Open http://localhost:5173. This project serves a compiled build in its current dev mode, so source changes require restarting that command.

Gemini mapping is optional. Enable it with ENABLE_AI_PART_DETECTION and configure GEMINI_API_KEY. When enabled, analyzed photographs are sent to Google for processing and usage may incur charges. Configure the primary and fallback model names explicitly because their documented defaults differ from the code.

### Verification results

During the project review, all six existing backend tests passed and the frontend production build completed successfully. Tests cover account and analysis flows, ownership protection, comparisons, report generation, and mocked vision fallback behavior. Browser interactions and live Gemini responses were not verified.

### Current limitations

- The small dataset and reported accuracy limit prediction reliability. There is no dedicated rejection model for unrelated photographs.

- AI part boxes are estimates, and no annotated part dataset is supplied for measuring their accuracy.

- The results page prominently displays a transformed score that is higher than actual confidence. It should be replaced or clearly explained.

- The frontend loads up to 100 analyses and comparisons without controls for older records.

- Large-image validation, concurrent comparison processing, and deployment configuration need further hardening.

### Future improvements

Priorities are to correct score presentation, expand and independently evaluate the training dataset, improve handling of unrelated images, add pagination, and optimize request processing. Deployment work should include persistent storage, HTTPS, stable secrets, and appropriate operational monitoring.

Project references: README.md; backend/README.md; frontend/README.md; backend/app; frontend/src; backend/tests.
