# Clean source package

This is a smaller copy of the supplied Temple Atlas project. Application source code has not been modified.

Removed: bundled virtual environments and Node dependencies, build output, caches, temporary files, logs, local .env settings, the saved backend database and user uploads/reports, and the unused architecture_model.joblib artifact.

Kept: frontend and backend source, dependency manifests and lockfile, tests, documentation, static frontend assets, all 150 training images, and the active numeric architecture_model.npz model.

The .env.example files contain fresh placeholders. Copy them to .env and configure your own stable JWT secret. Existing accounts and saved history are not included; the backend creates a new database at startup. Register a new account.

Install dependencies before running. See README.md for setup. Optional Gemini mapping is disabled by default. Model evaluation metadata was preserved; this cleanup does not retrain or improve the model.
